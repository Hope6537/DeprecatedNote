/*   */ package com.gaoxinyu.sail.exception;
/*   */ 
/*   */ public class ValidateErrorException extends RuntimeException
/*   */ {
/*   */   public ValidateErrorException(String message)
/*   */   {
/* 9 */     super(message);
/*   */   }
/*   */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.exception.ValidateErrorException
 * JD-Core Version:    0.6.0
 */