/*    */ package com.gaoxinyu.sail.exception;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.gaoxinyu.sail.ajax.response.AjaxResponse;
/*    */ import com.gaoxinyu.sail.ajax.response.ReturnState;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.shiro.authz.UnauthorizedException;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
/*    */ 
/*    */ public class CustomSimpleMappingExceptionResolver extends SimpleMappingExceptionResolver
/*    */ {
/* 25 */   private Logger logger = LoggerFactory.getLogger(getClass());
/*    */ 
/*    */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
/*    */   {
/* 30 */     String viewName = determineViewName(ex, request);
/* 31 */     if (viewName == null) {
/* 32 */       return null;
/*    */     }
/* 34 */     if (isJsonReturn(request)) {
/*    */       try {
/* 36 */         PrintWriter writer = response.getWriter();
/* 37 */         response.setStatus(400);
/*    */         String errorMsg;
/*    */         String errorMsg;
/* 39 */         if ((ex instanceof ValidateErrorException)) {
/* 40 */           errorMsg = "操作失败！" + ex.getMessage();
/*    */         }
/*    */         else
/*    */         {
/*    */           String errorMsg;
/* 41 */           if ((ex instanceof UnauthorizedException)) {
/* 42 */             errorMsg = "操作失败！权限不足！" + ex.getMessage();
/*    */           } else {
/* 44 */             this.logger.error("error", ex);
/* 45 */             errorMsg = "操作失败！  " + ex;
/*    */           }
/*    */         }
/* 47 */         writer.write(new ObjectMapper().writeValueAsString(new AjaxResponse(ReturnState.ERROR, errorMsg)));
/* 48 */         writer.flush();
/*    */       } catch (IOException e) {
/* 50 */         this.logger.error("error", ex);
/*    */       }
/* 52 */       return null;
/*    */     }
/* 54 */     this.logger.error("error", ex);
/* 55 */     Integer statusCode = determineStatusCode(request, viewName);
/* 56 */     if (statusCode != null) {
/* 57 */       applyStatusCodeIfPossible(request, response, statusCode.intValue());
/*    */     }
/* 59 */     return getModelAndView(viewName, ex, request);
/*    */   }
/*    */ 
/*    */   private boolean isJsonReturn(HttpServletRequest request)
/*    */   {
/* 64 */     String xRequestedWith = request.getHeader("X-Requested-With");
/* 65 */     return (request.getHeader("accept").contains("application/json")) || ((xRequestedWith != null) && (xRequestedWith.contains("XMLHttpRequest")));
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.exception.CustomSimpleMappingExceptionResolver
 * JD-Core Version:    0.6.0
 */