/*     */ package com.gaoxinyu.sail.exportexcel;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.ss.usermodel.Cell;
/*     */ import org.apache.poi.ss.usermodel.CellStyle;
/*     */ import org.apache.poi.ss.usermodel.Font;
/*     */ import org.apache.poi.ss.usermodel.Row;
/*     */ import org.apache.poi.ss.usermodel.Sheet;
/*     */ import org.apache.poi.ss.usermodel.Workbook;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*     */ import org.jsoup.Jsoup;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.select.Elements;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class ExportExcel
/*     */ {
/*  26 */   Logger logger = LoggerFactory.getLogger(getClass());
/*     */   protected CellStyle styleTitle;
/*     */   protected CellStyle styleHead;
/*     */   protected CellStyle styleDataC;
/*     */   protected CellStyle styleDataR;
/*     */   protected CellStyle styleDataL;
/*     */   public static final int LEFT = 0;
/*     */   public static final int CENTER = 1;
/*     */   public static final int RIGHT = 2;
/*     */   public static final String Excel2003 = "xls";
/*     */   public static final String Excel2007 = "xlsx";
/*  37 */   protected String excelVersion = "xls";
/*     */   protected Workbook wb;
/*     */ 
/*     */   public ExportExcel()
/*     */   {
/*  42 */     this("xls");
/*     */   }
/*     */ 
/*     */   public ExportExcel(String excelVersion)
/*     */   {
/*  47 */     if (excelVersion.equals("xls")) {
/*  48 */       this.wb = new HSSFWorkbook();
/*  49 */       this.excelVersion = "xls";
/*     */     } else {
/*  51 */       this.wb = new XSSFWorkbook();
/*  52 */       this.excelVersion = "xlsx";
/*     */     }
/*  54 */     styleInit(this.wb);
/*     */   }
/*     */ 
/*     */   public ExcelVO export(List list, CustomExcelHandler customExcelHandler, ExcelVO excelVO, HttpServletResponse response)
/*     */   {
/*     */     try
/*     */     {
/*  66 */       OutputStream os = null;
/*     */ 
/*  68 */       if (response != null) {
/*  69 */         os = response.getOutputStream();
/*  70 */         response.reset();
/*  71 */         response.setHeader("Content-disposition", "attachment; filename=" + excelVO.getFileName() + new SimpleDateFormat("yyyyMMdd").format(new Date()) + "." + this.excelVersion);
/*  72 */         response.setContentType("application/msexcel");
/*     */       }
/*     */ 
/*  75 */       Sheet sheet = this.wb.createSheet(excelVO.getTitle());
/*     */ 
/*  77 */       int colNum = excelVO.getColTitle().length;
/*     */ 
/*  79 */       Double[] sumArr = new Double[colNum];
/*     */ 
/*  81 */       sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, colNum - 1));
/*     */ 
/*  83 */       sheet.createFreezePane(0, excelVO.getTableHeadRowNum() + 1, 0, excelVO.getTableHeadRowNum() + 1);
/*     */ 
/*  85 */       Row row = sheet.createRow(0);
/*  86 */       Cell cell = row.createCell(0);
/*  87 */       cell.setCellValue(excelVO.getTitle());
/*  88 */       cell.setCellStyle(this.styleTitle);
/*     */ 
/*  90 */       customExcelHandler.titleHandler(sheet, this.styleHead);
/*     */ 
/*  92 */       row = sheet.createRow(excelVO.getTableHeadRowNum());
/*  93 */       boolean showSum = false;
/*  94 */       for (int i = 0; i < colNum; i++) {
/*  95 */         sheet.setColumnWidth(i, excelVO.getWidth()[i]);
/*  96 */         cell = row.createCell(i);
/*  97 */         cell.setCellValue(excelVO.getColTitle()[i]);
/*  98 */         cell.setCellStyle(this.styleHead);
/*     */ 
/* 100 */         sumArr[i] = Double.valueOf(0.0D);
/*     */ 
/* 102 */         if (excelVO.getSumFlag() != null) {
/* 103 */           showSum = (showSum) || (excelVO.getSumFlag()[i] != 0);
/*     */         }
/*     */       }
/*     */ 
/* 107 */       if ((list != null) && (list.size() > 0)) {
/* 108 */         int i = 0; for (int ii = list.size(); i < ii; i++) {
/* 109 */           row = sheet.createRow(i + excelVO.getTableHeadRowNum() + 1);
/*     */ 
/* 111 */           for (int j = 0; j < colNum; j++) {
/* 112 */             switch (excelVO.getAlign()[j]) {
/*     */             case 0:
/* 114 */               row.createCell(j).setCellStyle(this.styleDataL);
/* 115 */               break;
/*     */             case 1:
/* 117 */               row.createCell(j).setCellStyle(this.styleDataC);
/* 118 */               break;
/*     */             case 2:
/* 120 */               row.createCell(j).setCellStyle(this.styleDataR);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 125 */           customExcelHandler.rowHandler(list.get(i), row);
/*     */           try
/*     */           {
/* 128 */             if (showSum)
/* 129 */               for (int j = 0; j < colNum; j++)
/* 130 */                 if (excelVO.getSumFlag()[j] != 0) {
/* 131 */                   Double[] arrayOfDouble1 = sumArr; int i = j; (arrayOfDouble1[i] =  = Double.valueOf(arrayOfDouble1[i].doubleValue() + row.getCell(j).getNumericCellValue()));
/*     */                 }
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 136 */             this.logger.error("error", e);
/*     */           }
/*     */         }
/*     */ 
/* 140 */         if (showSum) {
/* 141 */           row = sheet.createRow(list.size() + excelVO.getTableHeadRowNum() + 1);
/* 142 */           for (int i = 0; i < colNum; i++) {
/* 143 */             cell = row.createCell(i);
/* 144 */             if (i == 0) {
/* 145 */               cell.setCellValue("合计");
/*     */             }
/* 147 */             else if (excelVO.getSumFlag()[i] != 0) {
/* 148 */               cell.setCellValue(sumArr[i].doubleValue());
/*     */             }
/*     */ 
/* 151 */             cell.setCellStyle(this.styleDataR);
/*     */           }
/*     */         }
/*     */       }
/* 155 */       excelVO.setWorkbook(this.wb);
/* 156 */       excelVO.setSheet(sheet);
/* 157 */       excelVO.setOutputStream(os);
/*     */     } catch (Exception e) {
/* 159 */       this.logger.error("error", e);
/*     */     }
/* 161 */     return excelVO;
/*     */   }
/*     */ 
/*     */   public Workbook exportExcelByHtml(ExcelVO excelVO)
/*     */   {
/*     */     try
/*     */     {
/* 172 */       int[] col = new int[excelVO.getColNum()];
/* 173 */       CellStyle[] colStyle = new CellStyle[excelVO.getColNum()];
/*     */ 
/* 175 */       Sheet sheet = this.wb.createSheet("sheet1");
/* 176 */       sheet.createFreezePane(0, excelVO.getTableHeadRowNum(), 0, excelVO.getTableHeadRowNum());
/*     */ 
/* 179 */       Document doc = Jsoup.parseBodyFragment(excelVO.getHtmlStr());
/* 180 */       Element body = doc.body();
/* 181 */       Elements trs = body.select("tr");
/*     */ 
/* 185 */       int tempRow = 0;
/* 186 */       int i = 0; for (int ii = trs.size(); i < ii; i++) {
/* 187 */         Elements tds = trs.get(i).select("th");
/* 188 */         if (tds.size() == 0) {
/* 189 */           tds = trs.get(i).select("td");
/*     */         }
/* 191 */         if (tds.size() != 0) {
/* 192 */           Row row = sheet.createRow(tempRow);
/* 193 */           tempRow++;
/*     */ 
/* 195 */           int j = 0; for (int tdIndex = 0; j < excelVO.getColNum(); j++)
/*     */           {
/* 197 */             if (col[j] != 0) {
/* 198 */               Cell cell = row.createCell(j);
/* 199 */               cell.setCellValue("");
/* 200 */               styleHandler(cell, colStyle, null, i, j, excelVO.getTableHeadRowNum());
/* 201 */               col[j] -= 1;
/*     */             }
/*     */             else {
/* 204 */               Cell cell = row.createCell(j);
/* 205 */               Element td = tds.get(tdIndex++);
/* 206 */               if (!"businessId".equals(td.attr("businessId")))
/*     */               {
/* 208 */                 if ((td.text().toLowerCase().endsWith("d")) || (td.text().toLowerCase().endsWith("f")))
/* 209 */                   cell.setCellValue(td.text());
/*     */                 else {
/*     */                   try {
/* 212 */                     cell.setCellValue(Double.parseDouble(td.text().replace(",", "")));
/* 213 */                     cell.setCellType(0);
/*     */                   } catch (Exception e) {
/* 215 */                     if (!"".equals(td.text()))
/* 216 */                       cell.setCellValue(td.text());
/*     */                   }
/*     */                 }
/*     */               }
/*     */               else {
/* 221 */                 cell.setCellValue(td.text());
/*     */               }
/* 223 */               styleHandler(cell, colStyle, td, i, j, excelVO.getTableHeadRowNum());
/* 224 */               String colspan = td.attr("colspan");
/* 225 */               int oriJ = j;
/* 226 */               if (!colspan.equals("")) {
/* 227 */                 sheet.addMergedRegion(new CellRangeAddress(i, i, j, j + Integer.parseInt(colspan) - 1));
/* 228 */                 int temp = j;
/*     */ 
/* 230 */                 for (j++; j <= temp + Integer.parseInt(colspan) - 1; j++) {
/* 231 */                   cell = row.createCell(j);
/* 232 */                   cell.setCellValue("");
/* 233 */                   styleHandler(cell, colStyle, null, i, j, excelVO.getTableHeadRowNum());
/*     */                 }
/* 235 */                 j--;
/*     */               }
/* 237 */               String rowspan = td.attr("rowspan");
/* 238 */               if (!rowspan.equals(""))
/* 239 */                 if (colspan.equals("")) {
/* 240 */                   col[j] = (Integer.parseInt(rowspan) - 1);
/* 241 */                   sheet.addMergedRegion(new CellRangeAddress(i, i + Integer.parseInt(rowspan) - 1, j, j));
/*     */                 } else {
/* 243 */                   int m = 0; for (int n = Integer.parseInt(colspan); m < n; m++) {
/* 244 */                     col[(oriJ + m)] = (Integer.parseInt(rowspan) - 1);
/*     */                   }
/* 246 */                   sheet.addMergedRegion(new CellRangeAddress(i, i + Integer.parseInt(rowspan) - 1, oriJ, oriJ + Integer.parseInt(colspan) - 1));
/*     */                 }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 252 */       for (int i = 0; i < excelVO.getColNum(); i++) {
/* 253 */         sheet.autoSizeColumn(i, true);
/* 254 */         sheet.setColumnWidth(i, (short)(sheet.getColumnWidth(i) + 500));
/*     */       }
/* 256 */       return this.wb;
/*     */     } catch (Exception e) {
/* 258 */       this.logger.error("error", e);
/* 259 */     }return null;
/*     */   }
/*     */ 
/*     */   public Cell styleHandler(Cell cell, CellStyle[] colStyle, Element td, int currentRow, int currentCol, int titleRowNum)
/*     */   {
/* 266 */     if (currentRow == 0) {
/* 267 */       cell.setCellStyle(this.styleTitle);
/*     */     }
/* 269 */     else if (currentRow < titleRowNum) {
/* 270 */       cell.setCellStyle(this.styleHead);
/*     */     }
/* 272 */     else if (currentRow == titleRowNum) {
/* 273 */       if (td != null) {
/* 274 */         String align = td.attr("align");
/* 275 */         if (("left".equals(align)) || ("".endsWith(align))) {
/* 276 */           cell.setCellStyle(this.styleDataL);
/* 277 */           colStyle[currentCol] = this.styleDataL;
/* 278 */         } else if (("center".equals(align)) || ("middle".equals(align))) {
/* 279 */           cell.setCellStyle(this.styleDataC);
/* 280 */           colStyle[currentCol] = this.styleDataC;
/* 281 */         } else if ("right".equals(align)) {
/* 282 */           cell.setCellStyle(this.styleDataR);
/* 283 */           colStyle[currentCol] = this.styleDataR;
/*     */         }
/*     */       }
/*     */       else {
/* 287 */         cell.setCellStyle(this.styleDataC);
/* 288 */         colStyle[currentCol] = this.styleDataC;
/*     */       }
/*     */     }
/*     */     else {
/* 292 */       cell.setCellStyle(colStyle[currentCol]);
/*     */     }
/* 294 */     return cell;
/*     */   }
/*     */ 
/*     */   protected void styleInit(Workbook wb)
/*     */   {
/* 300 */     Font fontTitle = wb.createFont();
/* 301 */     fontTitle.setBoldweight(10);
/* 302 */     fontTitle.setFontHeight(30);
/* 303 */     fontTitle.setColor(8);
/* 304 */     fontTitle.setFontHeightInPoints(10);
/* 305 */     fontTitle.setBoldweight(700);
/*     */ 
/* 307 */     this.styleTitle = wb.createCellStyle();
/* 308 */     this.styleTitle.setAlignment(2);
/* 309 */     this.styleTitle.setVerticalAlignment(1);
/* 310 */     this.styleTitle.setBorderRight(1);
/* 311 */     this.styleTitle.setFont(fontTitle);
/*     */ 
/* 314 */     Font fontHead = wb.createFont();
/* 315 */     fontHead.setFontHeightInPoints(10);
/* 316 */     fontHead.setBoldweight(700);
/*     */ 
/* 318 */     this.styleHead = wb.createCellStyle();
/* 319 */     this.styleHead.setAlignment(2);
/* 320 */     this.styleHead.setVerticalAlignment(1);
/*     */ 
/* 322 */     this.styleHead.setBorderBottom(1);
/* 323 */     this.styleHead.setBorderLeft(1);
/* 324 */     this.styleHead.setBorderRight(1);
/* 325 */     this.styleHead.setBorderTop(1);
/* 326 */     this.styleHead.setFont(fontHead);
/* 327 */     this.styleHead.setFillForegroundColor(22);
/* 328 */     this.styleHead.setFillPattern(1);
/*     */ 
/* 331 */     Font fontData = wb.createFont();
/* 332 */     fontData.setFontHeightInPoints(10);
/*     */ 
/* 335 */     this.styleDataC = wb.createCellStyle();
/* 336 */     this.styleDataC.setAlignment(2);
/* 337 */     this.styleDataC.setVerticalAlignment(1);
/* 338 */     this.styleDataC.setBorderBottom(1);
/* 339 */     this.styleDataC.setBorderLeft(1);
/* 340 */     this.styleDataC.setBorderRight(1);
/* 341 */     this.styleDataC.setBorderTop(1);
/* 342 */     this.styleDataC.setFont(fontData);
/*     */ 
/* 344 */     this.styleDataR = wb.createCellStyle();
/* 345 */     this.styleDataR.setAlignment(3);
/* 346 */     this.styleDataR.setVerticalAlignment(1);
/* 347 */     this.styleDataR.setBorderBottom(1);
/* 348 */     this.styleDataR.setBorderLeft(1);
/* 349 */     this.styleDataR.setBorderRight(1);
/* 350 */     this.styleDataR.setBorderTop(1);
/* 351 */     this.styleDataR.setFont(fontData);
/*     */ 
/* 353 */     this.styleDataL = wb.createCellStyle();
/* 354 */     this.styleDataL.setAlignment(1);
/* 355 */     this.styleDataL.setVerticalAlignment(1);
/* 356 */     this.styleDataL.setBorderBottom(1);
/* 357 */     this.styleDataL.setBorderLeft(1);
/* 358 */     this.styleDataL.setBorderRight(1);
/* 359 */     this.styleDataL.setBorderTop(1);
/* 360 */     this.styleDataL.setFont(fontData);
/*     */   }
/*     */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.exportexcel.ExportExcel
 * JD-Core Version:    0.6.0
 */