package com.gaoxinyu.sail.exportexcel;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

public class CustomExcelHandlerImpl
  implements CustomExcelHandler
{
  public void rowHandler(Object obj, Row row)
  {
  }

  public void titleHandler(Sheet sheet, CellStyle styleHead)
  {
  }
}

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.exportexcel.CustomExcelHandlerImpl
 * JD-Core Version:    0.6.0
 */