/*     */ package com.gaoxinyu.sail.exportexcel;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.poi.ss.usermodel.Sheet;
/*     */ import org.apache.poi.ss.usermodel.Workbook;
/*     */ 
/*     */ public class ExcelVO
/*     */ {
/*     */   private String fileName;
/*     */   private String title;
/*     */   private int tableHeadRowNum;
/*     */   private String[] colTitle;
/*     */   private int[] width;
/*     */   private int[] align;
/*     */   private boolean[] sumFlag;
/*     */   private String htmlStr;
/*     */   private int colNum;
/*     */   private String excelVersion;
/*     */   private Workbook workbook;
/*     */   private Sheet sheet;
/*     */   private OutputStream outputStream;
/*     */ 
/*     */   public ExcelVO()
/*     */   {
/*  33 */     this.tableHeadRowNum = 1;
/*     */   }
/*     */ 
/*     */   public ExcelVO(String fileName, String title, int tableHeadRowNum, String[] colTitle, int[] width, int[] align, boolean[] sumFlag)
/*     */   {
/*  46 */     this.fileName = fileName;
/*  47 */     this.title = title;
/*  48 */     this.tableHeadRowNum = tableHeadRowNum;
/*  49 */     this.colTitle = colTitle;
/*  50 */     this.width = width;
/*  51 */     this.align = align;
/*  52 */     this.sumFlag = sumFlag;
/*     */   }
/*     */ 
/*     */   public void workbookWriteOutSteam() throws IOException {
/*  56 */     if ((this.workbook != null) && (this.outputStream != null))
/*  57 */       this.workbook.write(this.outputStream);
/*     */   }
/*     */ 
/*     */   public String getFileName()
/*     */   {
/*  62 */     return this.fileName;
/*     */   }
/*     */ 
/*     */   public void setFileName(String fileName) {
/*  66 */     this.fileName = fileName;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/*  70 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setTitle(String title) {
/*  74 */     this.title = title;
/*     */   }
/*     */ 
/*     */   public int getTableHeadRowNum() {
/*  78 */     return this.tableHeadRowNum;
/*     */   }
/*     */ 
/*     */   public void setTableHeadRowNum(int tableHeadRowNum) {
/*  82 */     this.tableHeadRowNum = tableHeadRowNum;
/*     */   }
/*     */ 
/*     */   public String[] getColTitle() {
/*  86 */     return this.colTitle;
/*     */   }
/*     */ 
/*     */   public void setColTitle(String[] colTitle) {
/*  90 */     this.colTitle = colTitle;
/*     */   }
/*     */ 
/*     */   public int[] getWidth() {
/*  94 */     return this.width;
/*     */   }
/*     */ 
/*     */   public void setWidth(int[] width) {
/*  98 */     this.width = width;
/*     */   }
/*     */ 
/*     */   public int[] getAlign() {
/* 102 */     return this.align;
/*     */   }
/*     */ 
/*     */   public void setAlign(int[] align) {
/* 106 */     this.align = align;
/*     */   }
/*     */ 
/*     */   public boolean[] getSumFlag() {
/* 110 */     return this.sumFlag;
/*     */   }
/*     */ 
/*     */   public void setSumFlag(boolean[] sumFlag) {
/* 114 */     this.sumFlag = sumFlag;
/*     */   }
/*     */ 
/*     */   public String getHtmlStr() {
/* 118 */     return this.htmlStr;
/*     */   }
/*     */ 
/*     */   public void setHtmlStr(String htmlStr) {
/* 122 */     this.htmlStr = htmlStr;
/*     */   }
/*     */ 
/*     */   public int getColNum() {
/* 126 */     return this.colNum;
/*     */   }
/*     */ 
/*     */   public void setColNum(int colNum) {
/* 130 */     this.colNum = colNum;
/*     */   }
/*     */ 
/*     */   public String getExcelVersion() {
/* 134 */     return this.excelVersion;
/*     */   }
/*     */ 
/*     */   public void setExcelVersion(String excelVersion) {
/* 138 */     this.excelVersion = excelVersion;
/*     */   }
/*     */ 
/*     */   public Workbook getWorkbook() {
/* 142 */     return this.workbook;
/*     */   }
/*     */ 
/*     */   public void setWorkbook(Workbook workbook) {
/* 146 */     this.workbook = workbook;
/*     */   }
/*     */ 
/*     */   public Sheet getSheet() {
/* 150 */     return this.sheet;
/*     */   }
/*     */ 
/*     */   public void setSheet(Sheet sheet) {
/* 154 */     this.sheet = sheet;
/*     */   }
/*     */ 
/*     */   public OutputStream getOutputStream() {
/* 158 */     return this.outputStream;
/*     */   }
/*     */ 
/*     */   public void setOutputStream(OutputStream outputStream) {
/* 162 */     this.outputStream = outputStream;
/*     */   }
/*     */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.exportexcel.ExcelVO
 * JD-Core Version:    0.6.0
 */