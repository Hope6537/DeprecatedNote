/*    */ package com.gaoxinyu.sail.exportexcel;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ import java.util.Date;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.poi.ss.usermodel.Workbook;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.springframework.stereotype.Controller;
/*    */ import org.springframework.web.bind.annotation.RequestMapping;
/*    */ 
/*    */ @Controller
/*    */ public class ExportExcelController
/*    */ {
/* 17 */   Logger logger = LoggerFactory.getLogger(getClass());
/*    */ 
/*    */   @RequestMapping({"exportExcel/exportExcelByHtml"})
/*    */   public void exportExcelByHtml(ExcelVO excelVO, HttpServletRequest request, HttpServletResponse response) {
/*    */     try { ExportExcel exportExcel = new ExportExcel(excelVO.getExcelVersion());
/* 23 */       Workbook wb = exportExcel.exportExcelByHtml(excelVO);
/* 24 */       String fileName = String.valueOf(new Date().getTime()) + "." + excelVO.getExcelVersion();
/* 25 */       OutputStream os = response.getOutputStream();
/* 26 */       response.reset();
/* 27 */       response.setHeader("Content-disposition", "attachment; filename=" + fileName);
/* 28 */       response.setContentType("application/msexcel");
/* 29 */       wb.write(os);
/* 30 */       os.close();
/*    */     } catch (Exception e) {
/* 32 */       this.logger.error("error", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.exportexcel.ExportExcelController
 * JD-Core Version:    0.6.0
 */