package com.gaoxinyu.sail.exportexcel;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

public abstract interface CustomExcelHandler
{
  public abstract void rowHandler(Object paramObject, Row paramRow);

  public abstract void titleHandler(Sheet paramSheet, CellStyle paramCellStyle);
}

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.exportexcel.CustomExcelHandler
 * JD-Core Version:    0.6.0
 */