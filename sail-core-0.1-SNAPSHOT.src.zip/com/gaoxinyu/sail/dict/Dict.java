package com.gaoxinyu.sail.dict;

public class Dict
{
  public static final String SUCCESS = "success";
  public static final String ERROR = "error";
  public static final String OPERATE_SUCCESS = "操作成功！";
  public static final String OPERATE_ERROR = "操作失败！";
  public static final String NOT_PERMITTED = "权限不足！";
  public static final String STATE1 = "1";
  public static final String STATE2 = "2";
  public static final int AFFECTED_LINE_0 = 0;
  public static final int AFFECTED_LINE_1 = 1;
}

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.dict.Dict
 * JD-Core Version:    0.6.0
 */