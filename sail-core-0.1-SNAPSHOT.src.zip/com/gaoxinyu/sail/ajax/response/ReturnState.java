/*    */ package com.gaoxinyu.sail.ajax.response;
/*    */ 
/*    */ public enum ReturnState
/*    */ {
/*  9 */   OK, 
/* 10 */   WARNING, 
/* 11 */   ERROR;
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.ajax.response.ReturnState
 * JD-Core Version:    0.6.0
 */