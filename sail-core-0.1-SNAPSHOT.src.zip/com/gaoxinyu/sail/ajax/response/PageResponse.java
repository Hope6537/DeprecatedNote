/*    */ package com.gaoxinyu.sail.ajax.response;
/*    */ 
/*    */ import com.gaoxinyu.sail.mybatis.model.Page;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PageResponse<T>
/*    */ {
/*    */   private Page page;
/*    */   private List<T> resultList;
/*    */ 
/*    */   public PageResponse()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PageResponse(Page page, List<T> resultList)
/*    */   {
/* 18 */     this.page = page;
/* 19 */     this.resultList = resultList;
/*    */   }
/*    */ 
/*    */   public Page getPage() {
/* 23 */     return this.page;
/*    */   }
/*    */ 
/*    */   public void setPage(Page page) {
/* 27 */     this.page = page;
/*    */   }
/*    */ 
/*    */   public List<T> getResultList() {
/* 31 */     return this.resultList;
/*    */   }
/*    */ 
/*    */   public void setResultList(List<T> resultList) {
/* 35 */     this.resultList = resultList;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.ajax.response.PageResponse
 * JD-Core Version:    0.6.0
 */