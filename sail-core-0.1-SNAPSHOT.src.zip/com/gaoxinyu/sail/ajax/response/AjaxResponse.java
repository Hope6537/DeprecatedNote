/*    */ package com.gaoxinyu.sail.ajax.response;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.validation.BindingResult;
/*    */ import org.springframework.validation.ObjectError;
/*    */ 
/*    */ public class AjaxResponse
/*    */ {
/* 17 */   private ReturnState returnState = ReturnState.OK;
/*    */   private String returnMsg;
/* 21 */   private Map<String, Object> returnData = new HashMap();
/*    */ 
/*    */   public AjaxResponse() {
/* 24 */     this(ReturnState.OK, "");
/*    */   }
/*    */ 
/*    */   public AjaxResponse(String returnMsg) {
/* 28 */     this(ReturnState.OK, returnMsg);
/*    */   }
/*    */ 
/*    */   public AjaxResponse(ReturnState returnState, String returnMsg) {
/* 32 */     this.returnState = returnState;
/* 33 */     this.returnMsg = returnMsg;
/*    */   }
/*    */ 
/*    */   public AjaxResponse(String attributeName, Object attributeValue) {
/* 37 */     this();
/* 38 */     addAttribute(attributeName, attributeValue);
/*    */   }
/*    */ 
/*    */   public AjaxResponse(BindingResult result) {
/* 42 */     this.returnState = ReturnState.ERROR;
/* 43 */     this.returnMsg = "";
/* 44 */     for (ObjectError objectError : result.getAllErrors())
/* 45 */       this.returnMsg += objectError.getDefaultMessage();
/*    */   }
/*    */ 
/*    */   public static AjaxResponse getInstanceByResult(boolean result)
/*    */   {
/* 50 */     if (result) {
/* 51 */       return new AjaxResponse("操作成功！");
/*    */     }
/* 53 */     return new AjaxResponse(ReturnState.ERROR, "操作失败！");
/*    */   }
/*    */ 
/*    */   public boolean isOk()
/*    */   {
/* 58 */     return this.returnState == ReturnState.OK;
/*    */   }
/*    */ 
/*    */   public boolean isWarning() {
/* 62 */     return this.returnState == ReturnState.WARNING;
/*    */   }
/*    */ 
/*    */   public boolean isError() {
/* 66 */     return this.returnState == ReturnState.ERROR;
/*    */   }
/*    */ 
/*    */   public ReturnState getReturnState() {
/* 70 */     return this.returnState;
/*    */   }
/*    */ 
/*    */   public void setReturnState(ReturnState returnState) {
/* 74 */     this.returnState = returnState;
/*    */   }
/*    */ 
/*    */   public String getReturnMsg() {
/* 78 */     return this.returnMsg;
/*    */   }
/*    */ 
/*    */   public void setReturnMsg(String returnMsg) {
/* 82 */     this.returnMsg = returnMsg;
/*    */   }
/*    */ 
/*    */   public Map<String, Object> getReturnData() {
/* 86 */     if (this.returnData == null) {
/* 87 */       this.returnData = new HashMap();
/*    */     }
/* 89 */     return this.returnData;
/*    */   }
/*    */ 
/*    */   public void setReturnData(Map<String, Object> returnData) {
/* 93 */     this.returnData = returnData;
/*    */   }
/*    */ 
/*    */   public AjaxResponse addAttribute(String attributeName, Object attributeValue) {
/* 97 */     getReturnData().put(attributeName, attributeValue);
/* 98 */     return this;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.ajax.response.AjaxResponse
 * JD-Core Version:    0.6.0
 */