/*    */ package com.gaoxinyu.sail.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import net.sourceforge.pinyin4j.PinyinHelper;
/*    */ import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
/*    */ import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
/*    */ import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
/*    */ import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class Cn2Spell
/*    */ {
/*    */   public static String converterToFirstSpell(String chines)
/*    */   {
/* 17 */     return getSpellForZh(chines, true);
/*    */   }
/*    */ 
/*    */   public static String converterToSpell(String chines) {
/* 21 */     return getSpellForZh(chines, false);
/*    */   }
/*    */ 
/*    */   private static String getSpellForZh(String chines, boolean returnFirstSpell)
/*    */   {
/* 32 */     if ((chines == null) || ("".equals(chines))) {
/* 33 */       return "";
/*    */     }
/* 35 */     StringBuilder pinyinName = new StringBuilder();
/* 36 */     HanyuPinyinOutputFormat defaultFormat = new HanyuPinyinOutputFormat();
/* 37 */     defaultFormat.setCaseType(HanyuPinyinCaseType.LOWERCASE);
/* 38 */     defaultFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
/* 39 */     char[] nameChar = chines.toCharArray();
/* 40 */     for (char zhChar : nameChar) {
/* 41 */       if (zhChar > '') {
/* 42 */         String spell = returnFirstSpell ? getFirstSpellForChar(zhChar, defaultFormat) : getSpellForChar(zhChar, defaultFormat);
/* 43 */         pinyinName.append(spell);
/*    */       } else {
/* 45 */         pinyinName.append(zhChar);
/*    */       }
/*    */     }
/* 48 */     return pinyinName.toString();
/*    */   }
/*    */ 
/*    */   private static String getSpellForChar(char zhChar, HanyuPinyinOutputFormat defaultFormat) {
/*    */     try {
/* 53 */       String[] pinyin = PinyinHelper.toHanyuPinyinStringArray(zhChar, defaultFormat);
/* 54 */       if ((pinyin != null) && (pinyin.length != 0)) {
/* 55 */         return pinyin[0];
/*    */       }
/* 57 */       return String.valueOf(zhChar);
/*    */     }
/*    */     catch (BadHanyuPinyinOutputFormatCombination e) {
/* 60 */       LoggerFactory.getLogger(Cn2Spell.class).error("error", e);
/*    */     }
/* 62 */     return "";
/*    */   }
/*    */ 
/*    */   private static String getFirstSpellForChar(char zhChar, HanyuPinyinOutputFormat defaultFormat) {
/* 66 */     return getSpellForChar(zhChar, defaultFormat).substring(0, 1);
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 70 */     System.out.println(converterToSpell("我马上"));
/* 71 */     System.out.println(converterToFirstSpell("我马上"));
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.Cn2Spell
 * JD-Core Version:    0.6.0
 */