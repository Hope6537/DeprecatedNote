/*     */ package com.gaoxinyu.sail.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ public class MD5
/*     */ {
/*     */   static final int S11 = 7;
/*     */   static final int S12 = 12;
/*     */   static final int S13 = 17;
/*     */   static final int S14 = 22;
/*     */   static final int S21 = 5;
/*     */   static final int S22 = 9;
/*     */   static final int S23 = 14;
/*     */   static final int S24 = 20;
/*     */   static final int S31 = 4;
/*     */   static final int S32 = 11;
/*     */   static final int S33 = 16;
/*     */   static final int S34 = 23;
/*     */   static final int S41 = 6;
/*     */   static final int S42 = 10;
/*     */   static final int S43 = 15;
/*     */   static final int S44 = 21;
/*  26 */   static final byte[] PADDING = { -128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*  31 */   private long[] state = new long[4];
/*  32 */   private long[] count = new long[2];
/*  33 */   private byte[] buffer = new byte[64];
/*     */   public String digestHexStr;
/*  38 */   private byte[] digest = new byte[16];
/*     */ 
/*     */   public String getMD5ofStr(String inbuf)
/*     */   {
/*  42 */     md5Init();
/*  43 */     md5Update(inbuf.getBytes(), inbuf.length());
/*  44 */     md5Final();
/*  45 */     this.digestHexStr = "";
/*  46 */     for (int i = 0; i < 16; i++) {
/*  47 */       this.digestHexStr += byteHEX(this.digest[i]);
/*     */     }
/*  49 */     return this.digestHexStr;
/*     */   }
/*     */ 
/*     */   public MD5()
/*     */   {
/*  54 */     md5Init();
/*     */   }
/*     */ 
/*     */   private void md5Init()
/*     */   {
/*  61 */     this.count[0] = 0L;
/*  62 */     this.count[1] = 0L;
/*     */ 
/*  65 */     this.state[0] = 1732584193L;
/*  66 */     this.state[1] = 4023233417L;
/*  67 */     this.state[2] = 2562383102L;
/*  68 */     this.state[3] = 271733878L;
/*     */   }
/*     */ 
/*     */   private long F(long x, long y, long z)
/*     */   {
/*  75 */     return x & y | (x ^ 0xFFFFFFFF) & z;
/*     */   }
/*     */ 
/*     */   private long G(long x, long y, long z)
/*     */   {
/*  80 */     return x & z | y & (z ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   private long H(long x, long y, long z)
/*     */   {
/*  85 */     return x ^ y ^ z;
/*     */   }
/*     */ 
/*     */   private long I(long x, long y, long z) {
/*  89 */     return y ^ (x | z ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   private long FF(long a, long b, long c, long d, long x, long s, long ac)
/*     */   {
/*  95 */     a += F(b, c, d) + x + ac;
/*  96 */     a = (int)a << (int)s | (int)a >>> (int)(32L - s);
/*  97 */     a += b;
/*  98 */     return a;
/*     */   }
/*     */ 
/*     */   private long GG(long a, long b, long c, long d, long x, long s, long ac)
/*     */   {
/* 103 */     a += G(b, c, d) + x + ac;
/* 104 */     a = (int)a << (int)s | (int)a >>> (int)(32L - s);
/* 105 */     a += b;
/* 106 */     return a;
/*     */   }
/*     */ 
/*     */   private long HH(long a, long b, long c, long d, long x, long s, long ac)
/*     */   {
/* 111 */     a += H(b, c, d) + x + ac;
/* 112 */     a = (int)a << (int)s | (int)a >>> (int)(32L - s);
/* 113 */     a += b;
/* 114 */     return a;
/*     */   }
/*     */ 
/*     */   private long II(long a, long b, long c, long d, long x, long s, long ac)
/*     */   {
/* 119 */     a += I(b, c, d) + x + ac;
/* 120 */     a = (int)a << (int)s | (int)a >>> (int)(32L - s);
/* 121 */     a += b;
/* 122 */     return a;
/*     */   }
/*     */ 
/*     */   private void md5Update(byte[] inbuf, int inputLen)
/*     */   {
/* 128 */     byte[] block = new byte[64];
/* 129 */     int index = (int)(this.count[0] >>> 3) & 0x3F;
/*     */ 
/* 131 */     if (this.count[0] += (inputLen << 3) < inputLen << 3) {
/* 132 */       this.count[1] += 1L;
/*     */     }
/* 134 */     this.count[1] += (inputLen >>> 29);
/*     */ 
/* 136 */     int partLen = 64 - index;
/*     */     int i;
/* 139 */     if (inputLen >= partLen) {
/* 140 */       md5Memcpy(this.buffer, inbuf, index, 0, partLen);
/* 141 */       md5Transform(this.buffer);
/*     */ 
/* 143 */       for (int i = partLen; i + 63 < inputLen; i += 64)
/*     */       {
/* 145 */         md5Memcpy(block, inbuf, 0, i, 64);
/* 146 */         md5Transform(block);
/*     */       }
/* 148 */       index = 0;
/*     */     }
/*     */     else
/*     */     {
/* 152 */       i = 0;
/*     */     }
/*     */ 
/* 155 */     md5Memcpy(this.buffer, inbuf, index, i, inputLen - i);
/*     */   }
/*     */ 
/*     */   private void md5Final()
/*     */   {
/* 161 */     byte[] bits = new byte[8];
/*     */ 
/* 165 */     Encode(bits, this.count, 8);
/*     */ 
/* 168 */     int index = (int)(this.count[0] >>> 3) & 0x3F;
/* 169 */     int padLen = index < 56 ? 56 - index : 120 - index;
/* 170 */     md5Update(PADDING, padLen);
/*     */ 
/* 173 */     md5Update(bits, 8);
/*     */ 
/* 176 */     Encode(this.digest, this.state, 16);
/*     */   }
/*     */ 
/*     */   private void md5Memcpy(byte[] output, byte[] input, int outpos, int inpos, int len)
/*     */   {
/* 185 */     for (int i = 0; i < len; i++)
/* 186 */       output[(outpos + i)] = input[(inpos + i)];
/*     */   }
/*     */ 
/*     */   private void md5Transform(byte[] block)
/*     */   {
/* 191 */     long a = this.state[0]; long b = this.state[1]; long c = this.state[2]; long d = this.state[3];
/* 192 */     long[] x = new long[16];
/*     */ 
/* 194 */     Decode(x, block, 64);
/*     */ 
/* 197 */     a = FF(a, b, c, d, x[0], 7L, 3614090360L);
/* 198 */     d = FF(d, a, b, c, x[1], 12L, 3905402710L);
/* 199 */     c = FF(c, d, a, b, x[2], 17L, 606105819L);
/* 200 */     b = FF(b, c, d, a, x[3], 22L, 3250441966L);
/* 201 */     a = FF(a, b, c, d, x[4], 7L, 4118548399L);
/* 202 */     d = FF(d, a, b, c, x[5], 12L, 1200080426L);
/* 203 */     c = FF(c, d, a, b, x[6], 17L, 2821735955L);
/* 204 */     b = FF(b, c, d, a, x[7], 22L, 4249261313L);
/* 205 */     a = FF(a, b, c, d, x[8], 7L, 1770035416L);
/* 206 */     d = FF(d, a, b, c, x[9], 12L, 2336552879L);
/* 207 */     c = FF(c, d, a, b, x[10], 17L, 4294925233L);
/* 208 */     b = FF(b, c, d, a, x[11], 22L, 2304563134L);
/* 209 */     a = FF(a, b, c, d, x[12], 7L, 1804603682L);
/* 210 */     d = FF(d, a, b, c, x[13], 12L, 4254626195L);
/* 211 */     c = FF(c, d, a, b, x[14], 17L, 2792965006L);
/* 212 */     b = FF(b, c, d, a, x[15], 22L, 1236535329L);
/*     */ 
/* 215 */     a = GG(a, b, c, d, x[1], 5L, 4129170786L);
/* 216 */     d = GG(d, a, b, c, x[6], 9L, 3225465664L);
/* 217 */     c = GG(c, d, a, b, x[11], 14L, 643717713L);
/* 218 */     b = GG(b, c, d, a, x[0], 20L, 3921069994L);
/* 219 */     a = GG(a, b, c, d, x[5], 5L, 3593408605L);
/* 220 */     d = GG(d, a, b, c, x[10], 9L, 38016083L);
/* 221 */     c = GG(c, d, a, b, x[15], 14L, 3634488961L);
/* 222 */     b = GG(b, c, d, a, x[4], 20L, 3889429448L);
/* 223 */     a = GG(a, b, c, d, x[9], 5L, 568446438L);
/* 224 */     d = GG(d, a, b, c, x[14], 9L, 3275163606L);
/* 225 */     c = GG(c, d, a, b, x[3], 14L, 4107603335L);
/* 226 */     b = GG(b, c, d, a, x[8], 20L, 1163531501L);
/* 227 */     a = GG(a, b, c, d, x[13], 5L, 2850285829L);
/* 228 */     d = GG(d, a, b, c, x[2], 9L, 4243563512L);
/* 229 */     c = GG(c, d, a, b, x[7], 14L, 1735328473L);
/* 230 */     b = GG(b, c, d, a, x[12], 20L, 2368359562L);
/*     */ 
/* 233 */     a = HH(a, b, c, d, x[5], 4L, 4294588738L);
/* 234 */     d = HH(d, a, b, c, x[8], 11L, 2272392833L);
/* 235 */     c = HH(c, d, a, b, x[11], 16L, 1839030562L);
/* 236 */     b = HH(b, c, d, a, x[14], 23L, 4259657740L);
/* 237 */     a = HH(a, b, c, d, x[1], 4L, 2763975236L);
/* 238 */     d = HH(d, a, b, c, x[4], 11L, 1272893353L);
/* 239 */     c = HH(c, d, a, b, x[7], 16L, 4139469664L);
/* 240 */     b = HH(b, c, d, a, x[10], 23L, 3200236656L);
/* 241 */     a = HH(a, b, c, d, x[13], 4L, 681279174L);
/* 242 */     d = HH(d, a, b, c, x[0], 11L, 3936430074L);
/* 243 */     c = HH(c, d, a, b, x[3], 16L, 3572445317L);
/* 244 */     b = HH(b, c, d, a, x[6], 23L, 76029189L);
/* 245 */     a = HH(a, b, c, d, x[9], 4L, 3654602809L);
/* 246 */     d = HH(d, a, b, c, x[12], 11L, 3873151461L);
/* 247 */     c = HH(c, d, a, b, x[15], 16L, 530742520L);
/* 248 */     b = HH(b, c, d, a, x[2], 23L, 3299628645L);
/*     */ 
/* 251 */     a = II(a, b, c, d, x[0], 6L, 4096336452L);
/* 252 */     d = II(d, a, b, c, x[7], 10L, 1126891415L);
/* 253 */     c = II(c, d, a, b, x[14], 15L, 2878612391L);
/* 254 */     b = II(b, c, d, a, x[5], 21L, 4237533241L);
/* 255 */     a = II(a, b, c, d, x[12], 6L, 1700485571L);
/* 256 */     d = II(d, a, b, c, x[3], 10L, 2399980690L);
/* 257 */     c = II(c, d, a, b, x[10], 15L, 4293915773L);
/* 258 */     b = II(b, c, d, a, x[1], 21L, 2240044497L);
/* 259 */     a = II(a, b, c, d, x[8], 6L, 1873313359L);
/* 260 */     d = II(d, a, b, c, x[15], 10L, 4264355552L);
/* 261 */     c = II(c, d, a, b, x[6], 15L, 2734768916L);
/* 262 */     b = II(b, c, d, a, x[13], 21L, 1309151649L);
/* 263 */     a = II(a, b, c, d, x[4], 6L, 4149444226L);
/* 264 */     d = II(d, a, b, c, x[11], 10L, 3174756917L);
/* 265 */     c = II(c, d, a, b, x[2], 15L, 718787259L);
/* 266 */     b = II(b, c, d, a, x[9], 21L, 3951481745L);
/*     */ 
/* 268 */     this.state[0] += a;
/* 269 */     this.state[1] += b;
/* 270 */     this.state[2] += c;
/* 271 */     this.state[3] += d;
/*     */   }
/*     */ 
/*     */   private void Encode(byte[] output, long[] input, int len)
/*     */   {
/* 279 */     int i = 0; for (int j = 0; j < len; j += 4) {
/* 280 */       output[j] = (byte)(int)(input[i] & 0xFF);
/* 281 */       output[(j + 1)] = (byte)(int)(input[i] >>> 8 & 0xFF);
/* 282 */       output[(j + 2)] = (byte)(int)(input[i] >>> 16 & 0xFF);
/* 283 */       output[(j + 3)] = (byte)(int)(input[i] >>> 24 & 0xFF);
/*     */ 
/* 279 */       i++;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void Decode(long[] output, byte[] input, int len)
/*     */   {
/* 292 */     int i = 0; for (int j = 0; j < len; j += 4) {
/* 293 */       output[i] = (b2iu(input[j]) | b2iu(input[(j + 1)]) << 8 | b2iu(input[(j + 2)]) << 16 | b2iu(input[(j + 3)]) << 24);
/*     */ 
/* 292 */       i++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static long b2iu(byte b)
/*     */   {
/* 303 */     return b;
/*     */   }
/*     */ 
/*     */   public static String byteHEX(byte ib)
/*     */   {
/* 308 */     char[] Digit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/* 310 */     char[] ob = new char[2];
/* 311 */     ob[0] = Digit[(ib >>> 4 & 0xF)];
/* 312 */     ob[1] = Digit[(ib & 0xF)];
/* 313 */     String s = new String(ob);
/* 314 */     return s;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 319 */     MD5 m = new MD5();
/*     */ 
/* 321 */     if (Array.getLength(args) == 0)
/*     */     {
/* 323 */       System.out.println("MD5 Test suite:");
/* 324 */       System.out.println("MD5(\"\"):" + m.getMD5ofStr(""));
/* 325 */       System.out.println("MD5(\"a\"):" + m.getMD5ofStr("a"));
/* 326 */       System.out.println("MD5(\"abc\"):" + m.getMD5ofStr("abc"));
/* 327 */       System.out.println("MD5(\"message digest\"):" + m.getMD5ofStr("message digest"));
/* 328 */       System.out.println("MD5(\"abcdefghijklmnopqrstuvwxyz\"):" + m.getMD5ofStr("abcdefghijklmnopqrstuvwxyz"));
/*     */ 
/* 330 */       System.out.println("MD5(\"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789\"):" + m.getMD5ofStr("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"));
/*     */     }
/*     */     else {
/* 333 */       System.out.println("MD5(" + args[0] + ")=" + m.getMD5ofStr(args[0]));
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.MD5
 * JD-Core Version:    0.6.0
 */