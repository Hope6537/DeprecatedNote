/*     */ package com.gaoxinyu.sail.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.DecimalFormat;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class NumberUtil
/*     */ {
/*     */   public static String numFormat(Object num, String parser)
/*     */   {
/*  24 */     DecimalFormat df = new DecimalFormat(parser);
/*  25 */     df.setRoundingMode(RoundingMode.HALF_UP);
/*     */     try {
/*  27 */       if (num == null) {
/*  28 */         return df.format(0L);
/*     */       }
/*  30 */       if ((num instanceof String)) {
/*  31 */         return df.format(Double.parseDouble(String.valueOf(num).replace("--", "")));
/*     */       }
/*  33 */       String stringResult = df.format(num);
/*  34 */       if (Double.parseDouble(stringResult.replace(",", "")) == 0.0D)
/*     */       {
/*  36 */         return df.format(0L);
/*     */       }
/*  38 */       return stringResult;
/*     */     } catch (Exception e) {
/*  40 */       LoggerFactory.getLogger(NumberUtil.class).error("error", e);
/*  41 */     }return df.format(0L);
/*     */   }
/*     */ 
/*     */   public static String numFormat(Object num, int precision)
/*     */   {
/*  53 */     return numFormat(num, "0" + getZeroStr(precision));
/*     */   }
/*     */ 
/*     */   public static String numFormat(Object num)
/*     */   {
/*  63 */     return numFormat(num, "0" + getZeroStr(2));
/*     */   }
/*     */ 
/*     */   public static String getZeroStr(int num)
/*     */   {
/*  73 */     if (num == 0) {
/*  74 */       return "";
/*     */     }
/*  76 */     String str = ".";
/*  77 */     for (int i = 0; i < num; i++) {
/*  78 */       str = str + "0";
/*     */     }
/*  80 */     return str;
/*     */   }
/*     */ 
/*     */   public static String decimal3(Object num)
/*     */   {
/*  90 */     return numFormat(num, 3);
/*     */   }
/*     */ 
/*     */   public static String decimal5(Object num)
/*     */   {
/* 100 */     return numFormat(num, 5);
/*     */   }
/*     */ 
/*     */   public static String commaFormat(Object num)
/*     */   {
/* 110 */     return commaFormat(num, 2);
/*     */   }
/*     */ 
/*     */   public static String commaFormat(Object num, int precision)
/*     */   {
/* 121 */     return numFormat(num, "#,##0" + getZeroStr(precision));
/*     */   }
/*     */ 
/*     */   public static String intOrDouble(String num)
/*     */   {
/*     */     String newNum;
/*     */     String newNum;
/* 132 */     if (num.contains("."))
/*     */     {
/*     */       String newNum;
/* 133 */       if (getZeroStr(num.split("\\.")[1].length()).equals(num.split("\\.")[1]))
/* 134 */         newNum = num.split("\\.")[0];
/*     */       else
/* 136 */         newNum = num;
/*     */     }
/*     */     else {
/* 139 */       newNum = num;
/*     */     }
/* 141 */     return newNum;
/*     */   }
/*     */ 
/*     */   public static String trimZero(String str)
/*     */   {
/* 151 */     if (str.contains("."))
/*     */     {
/* 153 */       while (str.lastIndexOf("0") == str.length() - 1) {
/* 154 */         str = str.substring(0, str.lastIndexOf("0"));
/*     */       }
/*     */ 
/* 159 */       if (str.indexOf(".") == str.length() - 1) {
/* 160 */         str = str.substring(0, str.indexOf("."));
/*     */       }
/*     */     }
/* 163 */     return str;
/*     */   }
/*     */ 
/*     */   public static String getChnMoney(String strNum)
/*     */   {
/* 175 */     String output = "";
/* 176 */     if (strNum.equals("")) {
/* 177 */       return null;
/*     */     }
/* 179 */     int length = strNum.length();
/* 180 */     int pstn = strNum.indexOf(46);
/*     */     String subInput;
/*     */     int subLength;
/*     */     String subInput;
/* 182 */     if (pstn == -1) {
/* 183 */       int subLength = length;
/* 184 */       subInput = strNum;
/*     */     } else {
/* 186 */       subLength = pstn;
/* 187 */       subInput = strNum.substring(0, subLength);
/*     */     }
/*     */ 
/* 191 */     char[] array2 = { '仟', '佰', '拾' };
/* 192 */     char[] array3 = { '亿', '万', '元', 35282, '分' };
/*     */ 
/* 194 */     int n = subLength / 4;
/* 195 */     int m = subLength % 4;
/*     */ 
/* 197 */     if (m != 0) {
/* 198 */       for (int i = 0; i < 4 - m; i++) {
/* 199 */         subInput = '0' + subInput;
/*     */       }
/* 201 */       n += 1;
/*     */     }
/* 203 */     int k = n;
/*     */ 
/* 205 */     for (int i = 0; i < n; i++) {
/* 206 */       int p = 0;
/* 207 */       String change = subInput.substring(4 * i, 4 * (i + 1));
/* 208 */       char[] array = change.toCharArray();
/*     */ 
/* 210 */       for (int j = 0; j < 4; j++) {
/* 211 */         output = output + formatC(array[j]);
/* 212 */         if (j < 3) {
/* 213 */           output = output + array2[j];
/*     */         }
/* 215 */         p++;
/*     */       }
/*     */ 
/* 218 */       if (p != 0) {
/* 219 */         output = output + array3[(3 - k)];
/*     */       }
/*     */ 
/* 223 */       String[] str = { "零仟", "零佰", "零拾" };
/* 224 */       for (int s = 0; s < 3; s++) {
/*     */         while (true) {
/* 226 */           int q = output.indexOf(str[s]);
/* 227 */           if (q == -1) break;
/* 228 */           output = output.substring(0, q) + "零" + output.substring(q + str[s].length());
/*     */         }
/*     */       }
/*     */       int q;
/*     */       while (true)
/*     */       {
/* 235 */         q = output.indexOf("零零");
/* 236 */         if (q == -1) break;
/* 237 */         output = output.substring(0, q) + "零" + output.substring(q + 2);
/*     */       }
/*     */ 
/* 242 */       String[] str1 = { "零亿", "零万", "零元" };
/* 243 */       for (s = 0; s < 3; s++) {
/*     */         while (true) {
/* 245 */           q = output.indexOf(str1[s]);
/* 246 */           if (q == -1) break;
/* 247 */           output = output.substring(0, q) + output.substring(q + 1);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 253 */       k--;
/*     */     }
/*     */ 
/* 256 */     if (pstn != -1)
/*     */     {
/* 258 */       for (i = 1; i < length - pstn; i++) {
/* 259 */         if (strNum.charAt(pstn + i) != '0') {
/* 260 */           output = output + formatC(strNum.charAt(pstn + i));
/* 261 */           output = output + array3[(2 + i)];
/* 262 */         } else if (i < 2) {
/* 263 */           output = output + "零";
/*     */         } else {
/* 265 */           output = output + "";
/*     */         }
/*     */       }
/*     */     }
/* 269 */     if (output.substring(0, 1).equals("零")) {
/* 270 */       output = output.substring(1);
/*     */     }
/* 272 */     if (output.substring(output.length() - 1, output.length()).equals("零")) {
/* 273 */       output = output.substring(0, output.length() - 1);
/*     */     }
/* 275 */     return output + "整";
/*     */   }
/*     */ 
/*     */   private static String formatC(char x)
/*     */   {
/* 280 */     String a = "";
/* 281 */     switch (x) {
/*     */     case '0':
/* 283 */       a = "零";
/* 284 */       break;
/*     */     case '1':
/* 286 */       a = "壹";
/* 287 */       break;
/*     */     case '2':
/* 289 */       a = "贰";
/* 290 */       break;
/*     */     case '3':
/* 292 */       a = "叁";
/* 293 */       break;
/*     */     case '4':
/* 295 */       a = "肆";
/* 296 */       break;
/*     */     case '5':
/* 298 */       a = "伍";
/* 299 */       break;
/*     */     case '6':
/* 301 */       a = "陆";
/* 302 */       break;
/*     */     case '7':
/* 304 */       a = "柒";
/* 305 */       break;
/*     */     case '8':
/* 307 */       a = "捌";
/* 308 */       break;
/*     */     case '9':
/* 310 */       a = "玖";
/*     */     }
/*     */ 
/* 313 */     return a;
/*     */   }
/*     */ 
/*     */   public static double add(double v1, double v2)
/*     */   {
/* 324 */     BigDecimal b1 = new BigDecimal(Double.toString(v1));
/* 325 */     BigDecimal b2 = new BigDecimal(Double.toString(v2));
/* 326 */     return b1.add(b2).doubleValue();
/*     */   }
/*     */ 
/*     */   public static double sub(double v1, double v2)
/*     */   {
/* 337 */     BigDecimal b1 = new BigDecimal(Double.toString(v1));
/* 338 */     BigDecimal b2 = new BigDecimal(Double.toString(v2));
/* 339 */     return b1.subtract(b2).doubleValue();
/*     */   }
/*     */ 
/*     */   public static double mul(double v1, double v2)
/*     */   {
/* 350 */     BigDecimal b1 = new BigDecimal(Double.toString(v1));
/* 351 */     BigDecimal b2 = new BigDecimal(Double.toString(v2));
/* 352 */     return b1.multiply(b2).doubleValue();
/*     */   }
/*     */ 
/*     */   public static double div(double v1, double v2, int scale)
/*     */   {
/* 364 */     if (scale < 0) {
/* 365 */       throw new IllegalArgumentException("The scale must be a positive integer or zero");
/*     */     }
/* 367 */     BigDecimal b1 = new BigDecimal(Double.toString(v1));
/* 368 */     BigDecimal b2 = new BigDecimal(Double.toString(v2));
/* 369 */     return b1.divide(b2, scale, 4).doubleValue();
/*     */   }
/*     */ 
/*     */   public static double round(double v, int scale)
/*     */   {
/* 380 */     if (scale < 0) {
/* 381 */       throw new IllegalArgumentException("The scale must be a positive integer or zero");
/*     */     }
/* 383 */     BigDecimal b = new BigDecimal(Double.toString(v));
/* 384 */     BigDecimal one = new BigDecimal("1");
/* 385 */     return b.divide(one, scale, 4).doubleValue();
/*     */   }
/*     */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.NumberUtil
 * JD-Core Version:    0.6.0
 */