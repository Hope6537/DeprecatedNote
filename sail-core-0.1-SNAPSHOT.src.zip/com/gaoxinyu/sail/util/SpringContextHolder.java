/*    */ package com.gaoxinyu.sail.util;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.context.annotation.Lazy;
/*    */ import org.springframework.stereotype.Component;
/*    */ 
/*    */ @Component
/*    */ @Lazy(false)
/*    */ public class SpringContextHolder
/*    */   implements ApplicationContextAware
/*    */ {
/*    */   private static ApplicationContext applicationContext;
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext applicationContext)
/*    */   {
/* 25 */     applicationContext = applicationContext;
/*    */   }
/*    */ 
/*    */   public static ApplicationContext getApplicationContext()
/*    */   {
/* 32 */     checkApplicationContext();
/* 33 */     return applicationContext;
/*    */   }
/*    */ 
/*    */   public static <T> T getBean(String name)
/*    */   {
/* 41 */     checkApplicationContext();
/* 42 */     return applicationContext.getBean(name);
/*    */   }
/*    */ 
/*    */   public static <T> T getBean(Class<T> clazz)
/*    */   {
/* 50 */     checkApplicationContext();
/* 51 */     return applicationContext.getBeansOfType(clazz);
/*    */   }
/*    */ 
/*    */   private static void checkApplicationContext() {
/* 55 */     if (applicationContext == null)
/* 56 */       throw new IllegalStateException("applicaitonContext未注入,请在applicationContext.xml中定义SpringContextHolder");
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.SpringContextHolder
 * JD-Core Version:    0.6.0
 */