/*    */ package com.gaoxinyu.sail.util;
/*    */ 
/*    */ import java.text.DateFormat;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class DateUtil
/*    */ {
/*    */   public static String getMonthAdd(String operateDate, int flag)
/*    */     throws ParseException
/*    */   {
/* 21 */     if (operateDate.length() == 7) {
/* 22 */       operateDate = operateDate + "-01";
/*    */     }
/* 24 */     DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/* 25 */     Calendar c1 = Calendar.getInstance();
/* 26 */     c1.setTime(sdf.parse(operateDate));
/* 27 */     c1.add(2, flag);
/* 28 */     return sdf.format(c1.getTime()).substring(0, 7);
/*    */   }
/*    */ 
/*    */   public static String dateFormat(String datetime)
/*    */   {
/* 38 */     String date = "";
/* 39 */     if ((datetime != null) && (!"null".equals(datetime.trim())) && (!"".equals(datetime.trim())) && (datetime.length() > 10)) {
/* 40 */       if ("00:00:00".equals(datetime.substring(11, 19)))
/* 41 */         date = datetime.substring(0, 10);
/*    */       else
/* 43 */         date = datetime.substring(0, 19);
/*    */     }
/*    */     else {
/* 46 */       date = datetime;
/*    */     }
/* 48 */     return date;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.DateUtil
 * JD-Core Version:    0.6.0
 */