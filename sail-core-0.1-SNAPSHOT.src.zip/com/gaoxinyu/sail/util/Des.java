/*     */ package com.gaoxinyu.sail.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.security.Key;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class Des
/*     */ {
/*  15 */   Logger logger = LoggerFactory.getLogger(getClass());
/*     */ 
/*  19 */   private String strDefaultKey = "abcde";
/*     */ 
/*     */   public Des() {
/*     */   }
/*     */ 
/*     */   public Des(String strDefaultKey) {
/*  25 */     this.strDefaultKey = strDefaultKey;
/*     */   }
/*     */ 
/*     */   private String byteArr2HexStr(byte[] arrB)
/*     */     throws Exception
/*     */   {
/*  37 */     int iLen = arrB.length;
/*     */ 
/*  39 */     StringBuilder sb = new StringBuilder(iLen * 2);
/*  40 */     for (int intTmp : arrB)
/*     */     {
/*  42 */       while (intTmp < 0) {
/*  43 */         intTmp += 256;
/*     */       }
/*     */ 
/*  46 */       if (intTmp < 16) {
/*  47 */         sb.append("0");
/*     */       }
/*  49 */       sb.append(Integer.toString(intTmp, 16));
/*     */     }
/*  51 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private byte[] hexStr2ByteArr(String strIn)
/*     */     throws Exception
/*     */   {
/*  63 */     byte[] arrB = strIn.getBytes();
/*  64 */     int iLen = arrB.length;
/*     */ 
/*  67 */     byte[] arrOut = new byte[iLen / 2];
/*  68 */     for (int i = 0; i < iLen; i += 2) {
/*  69 */       String strTmp = new String(arrB, i, 2);
/*  70 */       arrOut[(i / 2)] = (byte)Integer.parseInt(strTmp, 16);
/*     */     }
/*  72 */     return arrOut;
/*     */   }
/*     */ 
/*     */   public byte[] encrypt(byte[] arrB)
/*     */     throws Exception
/*     */   {
/*  84 */     Key key = getKey(this.strDefaultKey.getBytes());
/*  85 */     Cipher cipher = Cipher.getInstance("DES");
/*  86 */     cipher.init(1, key);
/*  87 */     return cipher.doFinal(arrB);
/*     */   }
/*     */ 
/*     */   public String encrypt(String strIn)
/*     */   {
/*     */     try
/*     */     {
/*  98 */       return byteArr2HexStr(encrypt(strIn.getBytes()));
/*     */     } catch (Exception e) {
/* 100 */       this.logger.error("error", e);
/* 101 */     }return null;
/*     */   }
/*     */ 
/*     */   public byte[] decrypt(byte[] arrB)
/*     */     throws Exception
/*     */   {
/* 113 */     Key key = getKey(this.strDefaultKey.getBytes());
/* 114 */     Cipher cipher = Cipher.getInstance("DES");
/* 115 */     cipher.init(2, key);
/* 116 */     return cipher.doFinal(arrB);
/*     */   }
/*     */ 
/*     */   public String decrypt(String strIn)
/*     */   {
/*     */     try
/*     */     {
/* 127 */       return new String(decrypt(hexStr2ByteArr(strIn)));
/*     */     } catch (Exception e) {
/* 129 */       this.logger.error("error", e);
/* 130 */     }return null;
/*     */   }
/*     */ 
/*     */   private Key getKey(byte[] arrBTmp)
/*     */     throws Exception
/*     */   {
/* 143 */     byte[] arrB = new byte[8];
/*     */ 
/* 146 */     for (int i = 0; (i < arrBTmp.length) && (i < arrB.length); i++) {
/* 147 */       arrB[i] = arrBTmp[i];
/*     */     }
/*     */ 
/* 152 */     return new SecretKeySpec(arrB, "DES");
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 156 */     Des des = new Des();
/* 157 */     String e = "";
/*     */ 
/* 159 */     String d = des.encrypt(e);
/* 160 */     System.out.println(d);
/*     */   }
/*     */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.Des
 * JD-Core Version:    0.6.0
 */