/*    */ package com.gaoxinyu.sail.util;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ReflectUtil
/*    */ {
/*    */   public static Field getFieldByFieldName(Object obj, String fieldName)
/*    */   {
/* 18 */     Field field = null;
/* 19 */     for (Class clazz = obj.getClass(); clazz != Object.class; clazz = clazz.getSuperclass()) {
/*    */       try {
/* 21 */         field = clazz.getDeclaredField(fieldName);
/*    */       }
/*    */       catch (NoSuchFieldException e)
/*    */       {
/*    */       }
/*    */     }
/* 27 */     return field;
/*    */   }
/*    */ 
/*    */   public static <T> T getValueByFieldName(Object obj, String fieldName)
/*    */   {
/* 38 */     Object result = null;
/* 39 */     Field field = getFieldByFieldName(obj, fieldName);
/* 40 */     if (field != null) {
/* 41 */       field.setAccessible(true);
/*    */       try {
/* 43 */         result = field.get(obj);
/*    */       } catch (IllegalAccessException e) {
/* 45 */         LoggerFactory.getLogger(ReflectUtil.class).error("error", e);
/*    */       }
/*    */     }
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */   public static void setValueByFieldName(Object obj, String fieldName, Object value)
/*    */     throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException
/*    */   {
/* 65 */     Field field = obj.getClass().getDeclaredField(fieldName);
/* 66 */     if (field.isAccessible()) {
/* 67 */       field.set(obj, value);
/*    */     } else {
/* 69 */       field.setAccessible(true);
/* 70 */       field.set(obj, value);
/* 71 */       field.setAccessible(false);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.ReflectUtil
 * JD-Core Version:    0.6.0
 */