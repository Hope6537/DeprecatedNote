/*    */ package com.gaoxinyu.sail.util;
/*    */ 
/*    */ public class ExcelUtil
/*    */ {
/*    */   public static String excelIndexToLetter(int index)
/*    */   {
/* 15 */     String letter = "";
/* 16 */     int remainder = index % 26;
/* 17 */     letter = (char)(remainder + 65) + letter;
/* 18 */     index = (index - remainder) / 26;
/* 19 */     while (index > 0) {
/* 20 */       index--;
/* 21 */       remainder = index % 26;
/* 22 */       index = (index - remainder) / 26;
/* 23 */       letter = (char)(remainder + 65) + letter;
/*    */     }
/* 25 */     return letter;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.ExcelUtil
 * JD-Core Version:    0.6.0
 */