/*    */ package com.gaoxinyu.sail.util;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ public class StringUtil
/*    */ {
/*    */   public static boolean notEmpty(String s)
/*    */   {
/* 17 */     return (s != null) && (!"".equals(s)) && (!"null".equals(s));
/*    */   }
/*    */ 
/*    */   public static boolean isEmpty(String s)
/*    */   {
/* 27 */     return (s == null) || ("".equals(s)) || ("null".equals(s));
/*    */   }
/*    */ 
/*    */   public static List<String> StringToList(String str)
/*    */   {
/* 32 */     String[] returnStr = str.split(",");
/* 33 */     return Arrays.asList(returnStr);
/*    */   }
/*    */ 
/*    */   public static StringBuilder deleteLastChar(StringBuilder StrBuilder)
/*    */   {
/* 38 */     if (StrBuilder.length() > 1) {
/* 39 */       StrBuilder.deleteCharAt(StrBuilder.length() - 1);
/*    */     }
/* 41 */     return StrBuilder;
/*    */   }
/*    */ 
/*    */   public static String getBusinessIdDate(String operateTime) {
/* 45 */     return operateTime.replace("-", "").substring(2, 8);
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.util.StringUtil
 * JD-Core Version:    0.6.0
 */