/*    */ package com.gaoxinyu.sail.autocomplete.service;
/*    */ 
/*    */ import com.gaoxinyu.sail.autocomplete.model.AutoComplete;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class AbstractAutoCompleteService
/*    */   implements AutoCompleteService
/*    */ {
/*    */   private Map<String, List<AutoComplete>> autoCompleteMap;
/*    */ 
/*    */   public void initAutoComplete()
/*    */   {
/* 19 */     initAutoCompleteMap();
/* 20 */     initAutoCompleteSpell();
/*    */   }
/*    */ 
/*    */   protected abstract void initAutoCompleteMap();
/*    */ 
/*    */   private void initAutoCompleteSpell()
/*    */   {
/* 32 */     Map map = getAutoCompleteMap();
/* 33 */     for (String str : map.keySet())
/* 34 */       initAutoCompleteSpell((List)map.get(str));
/*    */   }
/*    */ 
/*    */   protected void initAutoCompleteSpell(List<AutoComplete> list)
/*    */   {
/* 42 */     if (list == null) {
/* 43 */       return;
/*    */     }
/* 45 */     for (AutoComplete autoCompleteVO : list)
/* 46 */       autoCompleteVO.setSpellAndFirstSpellByName();
/*    */   }
/*    */ 
/*    */   public List<AutoComplete> getAutoCompleteResultList(AutoComplete autoCompleteParam)
/*    */   {
/* 57 */     return getMatchAutoCompleteList(autoCompleteParam, getAllAutoCompleteList(autoCompleteParam));
/*    */   }
/*    */ 
/*    */   private List<AutoComplete> getAllAutoCompleteList(AutoComplete autoCompleteParam)
/*    */   {
/* 67 */     return (List)getAutoCompleteMap().get(autoCompleteParam.getFlag());
/*    */   }
/*    */ 
/*    */   protected List<AutoComplete> getMatchAutoCompleteList(AutoComplete autoCompleteParam, List<AutoComplete> autoCompleteList)
/*    */   {
/* 77 */     List autoCompleteResultList = new ArrayList();
/* 78 */     if ((autoCompleteList == null) || (autoCompleteList.size() <= 0)) {
/* 79 */       return autoCompleteList;
/*    */     }
/* 81 */     for (AutoComplete autoCompleteVO : autoCompleteList) {
/* 82 */       if ((!autoCompleteParam.isShowAll()) && (autoCompleteResultList.size() >= 10)) {
/*    */         break;
/*    */       }
/* 85 */       if (autoCompleteVO.contain(autoCompleteParam.getKeyword())) {
/* 86 */         autoCompleteResultList.add(autoCompleteVO);
/*    */       }
/*    */     }
/* 89 */     return autoCompleteResultList;
/*    */   }
/*    */ 
/*    */   public Map<String, List<AutoComplete>> getAutoCompleteMap() {
/* 93 */     return this.autoCompleteMap;
/*    */   }
/*    */ 
/*    */   public void setAutoCompleteMap(Map<String, List<AutoComplete>> autoCompleteMap) {
/* 97 */     this.autoCompleteMap = autoCompleteMap;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.autocomplete.service.AbstractAutoCompleteService
 * JD-Core Version:    0.6.0
 */