package com.gaoxinyu.sail.autocomplete.service;

import com.gaoxinyu.sail.autocomplete.model.AutoComplete;
import java.util.List;

public abstract interface AutoCompleteService
{
  public abstract void initAutoComplete();

  public abstract List<AutoComplete> getAutoCompleteResultList(AutoComplete paramAutoComplete);
}

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.autocomplete.service.AutoCompleteService
 * JD-Core Version:    0.6.0
 */