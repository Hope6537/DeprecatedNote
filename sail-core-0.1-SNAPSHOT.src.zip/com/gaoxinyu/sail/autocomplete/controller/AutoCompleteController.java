/*    */ package com.gaoxinyu.sail.autocomplete.controller;
/*    */ 
/*    */ import com.gaoxinyu.sail.autocomplete.model.AutoComplete;
/*    */ import com.gaoxinyu.sail.autocomplete.service.AutoCompleteService;
/*    */ import java.util.List;
/*    */ import org.springframework.web.bind.annotation.RequestMapping;
/*    */ import org.springframework.web.bind.annotation.ResponseBody;
/*    */ 
/*    */ @RequestMapping({"/autoComplete"})
/*    */ public class AutoCompleteController
/*    */ {
/*    */   private AutoCompleteService autoCompleteService;
/*    */ 
/*    */   public void setAutoCompleteService(AutoCompleteService autoCompleteService)
/*    */   {
/* 21 */     this.autoCompleteService = autoCompleteService;
/*    */   }
/* 27 */   @RequestMapping
/*    */   @ResponseBody
/*    */   public List<AutoComplete> autoComplete(AutoComplete autoCompleteParam) { return this.autoCompleteService.getAutoCompleteResultList(autoCompleteParam);
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.autocomplete.controller.AutoCompleteController
 * JD-Core Version:    0.6.0
 */