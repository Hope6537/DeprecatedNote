/*    */ package com.gaoxinyu.sail.autocomplete.model;
/*    */ 
/*    */ import com.gaoxinyu.sail.util.Cn2Spell;
/*    */ 
/*    */ public class AutoComplete
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */   private String spell;
/*    */   private String firstSpell;
/*    */   private String keyword;
/*    */   private boolean isShowAll;
/*    */   private String flag;
/*    */ 
/*    */   public AutoComplete()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AutoComplete(String id, String name)
/*    */   {
/* 21 */     this.id = id;
/* 22 */     this.name = name;
/* 23 */     setSpellAndFirstSpellByName();
/*    */   }
/*    */ 
/*    */   public void setSpellAndFirstSpellByName() {
/* 27 */     setSpell(Cn2Spell.converterToSpell(getName()));
/* 28 */     setFirstSpell(Cn2Spell.converterToFirstSpell(getName()));
/*    */   }
/*    */ 
/*    */   public boolean contain(String keyword) {
/* 32 */     return (getSpell().contains(keyword)) || (getFirstSpell().contains(keyword)) || (getName().toLowerCase().contains(keyword));
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 36 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String id) {
/* 40 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 44 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 48 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getSpell() {
/* 52 */     return this.spell;
/*    */   }
/*    */ 
/*    */   public void setSpell(String spell) {
/* 56 */     this.spell = spell;
/*    */   }
/*    */ 
/*    */   public String getFirstSpell() {
/* 60 */     return this.firstSpell;
/*    */   }
/*    */ 
/*    */   public void setFirstSpell(String firstSpell) {
/* 64 */     this.firstSpell = firstSpell;
/*    */   }
/*    */ 
/*    */   public String getKeyword() {
/* 68 */     return this.keyword;
/*    */   }
/*    */ 
/*    */   public void setKeyword(String keyword) {
/* 72 */     this.keyword = keyword.toLowerCase();
/*    */   }
/*    */ 
/*    */   public boolean isShowAll() {
/* 76 */     return this.isShowAll;
/*    */   }
/*    */ 
/*    */   public void setIsShowAll(boolean showAll) {
/* 80 */     this.isShowAll = showAll;
/*    */   }
/*    */ 
/*    */   public String getFlag() {
/* 84 */     return this.flag;
/*    */   }
/*    */ 
/*    */   public void setFlag(String flag) {
/* 88 */     this.flag = flag;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.autocomplete.model.AutoComplete
 * JD-Core Version:    0.6.0
 */