/*     */ package com.gaoxinyu.sail.mybatis.interceptor;
/*     */ 
/*     */ import com.gaoxinyu.sail.mybatis.model.Page;
/*     */ import com.gaoxinyu.sail.util.ReflectUtil;
/*     */ import com.gaoxinyu.sail.util.StringUtil;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.xml.bind.PropertyException;
/*     */ import org.apache.ibatis.executor.ErrorContext;
/*     */ import org.apache.ibatis.executor.ExecutorException;
/*     */ import org.apache.ibatis.executor.statement.BaseStatementHandler;
/*     */ import org.apache.ibatis.executor.statement.RoutingStatementHandler;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ParameterMap;
/*     */ import org.apache.ibatis.mapping.ParameterMapping;
/*     */ import org.apache.ibatis.mapping.ParameterMode;
/*     */ import org.apache.ibatis.plugin.Interceptor;
/*     */ import org.apache.ibatis.plugin.Intercepts;
/*     */ import org.apache.ibatis.plugin.Invocation;
/*     */ import org.apache.ibatis.plugin.Plugin;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.property.PropertyTokenizer;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ @Intercepts({@org.apache.ibatis.plugin.Signature(type=org.apache.ibatis.executor.statement.StatementHandler.class, method="prepare", args={Connection.class})})
/*     */ public class PageInterceptor
/*     */   implements Interceptor
/*     */ {
/*  42 */   Logger logger = LoggerFactory.getLogger(getClass());
/*     */ 
/*  44 */   private static String dialect = "";
/*  45 */   private static String pageSqlId = "";
/*     */ 
/*     */   public Object intercept(Invocation ivk) throws Throwable {
/*  48 */     if ((ivk.getTarget() instanceof RoutingStatementHandler)) {
/*  49 */       RoutingStatementHandler statementHandler = (RoutingStatementHandler)ivk.getTarget();
/*  50 */       BaseStatementHandler delegate = (BaseStatementHandler)ReflectUtil.getValueByFieldName(statementHandler, "delegate");
/*  51 */       MappedStatement mappedStatement = (MappedStatement)ReflectUtil.getValueByFieldName(delegate, "mappedStatement");
/*     */ 
/*  53 */       if (mappedStatement.getId().matches(pageSqlId)) {
/*  54 */         BoundSql boundSql = delegate.getBoundSql();
/*  55 */         Object parameterObject = boundSql.getParameterObject();
/*  56 */         if (parameterObject == null) {
/*  57 */           throw new NullPointerException("parameterObject尚未实例化！");
/*     */         }
/*  59 */         Connection connection = (Connection)ivk.getArgs()[0];
/*  60 */         Page page = getPage(parameterObject);
/*  61 */         page.setTotalResult(getTotalResult(statementHandler, connection));
/*  62 */         if ((page.hasSumColumns()) && (page.lessThanMaxSumLimit())) {
/*  63 */           page.setSumResult(getSumResult(statementHandler, connection, page));
/*     */         }
/*  65 */         String pageSql = generatePageSql(boundSql.getSql(), page);
/*  66 */         ReflectUtil.setValueByFieldName(boundSql, "sql", pageSql);
/*     */       }
/*     */     }
/*     */ 
/*  70 */     return ivk.proceed();
/*     */   }
/*     */ 
/*     */   private Page getPage(Object parameterObject) throws NoSuchFieldException {
/*  74 */     Page page = null;
/*  75 */     if ((parameterObject instanceof Page)) {
/*  76 */       page = (Page)parameterObject;
/*  77 */     } else if ((parameterObject instanceof Map)) {
/*  78 */       Map map = (Map)parameterObject;
/*  79 */       page = (Page)map.get("page");
/*  80 */       if (page == null) {
/*  81 */         page = new Page();
/*     */       }
/*     */     }
/*  84 */     return page;
/*     */   }
/*     */ 
/*     */   private int getTotalResult(RoutingStatementHandler statementHandler, Connection connection) {
/*  88 */     int totalResult = 0;
/*     */     try {
/*  90 */       BaseStatementHandler delegate = (BaseStatementHandler)ReflectUtil.getValueByFieldName(statementHandler, "delegate");
/*  91 */       MappedStatement mappedStatement = (MappedStatement)ReflectUtil.getValueByFieldName(delegate, "mappedStatement");
/*  92 */       BoundSql boundSql = delegate.getBoundSql();
/*  93 */       Object parameterObject = boundSql.getParameterObject();
/*  94 */       String sql = boundSql.getSql();
/*  95 */       String countSql = new StringBuilder().append("select count(0) from (").append(sql).append(") as tmp_count").toString();
/*  96 */       PreparedStatement countStmt = connection.prepareStatement(countSql);
/*  97 */       BoundSql countBS = new BoundSql(mappedStatement.getConfiguration(), countSql, boundSql.getParameterMappings(), parameterObject);
/*  98 */       setParameters(countStmt, mappedStatement, countBS, parameterObject);
/*  99 */       ResultSet rs = countStmt.executeQuery();
/* 100 */       if (rs.next()) {
/* 101 */         totalResult = rs.getInt(1);
/*     */       }
/* 103 */       rs.close();
/* 104 */       countStmt.close();
/*     */     } catch (SQLException e) {
/* 106 */       this.logger.error("error", e);
/*     */     }
/* 108 */     return totalResult;
/*     */   }
/*     */ 
/*     */   private Map<String, String> getSumResult(RoutingStatementHandler statementHandler, Connection connection, Page page) throws SQLException {
/* 112 */     Map sumResultMap = new HashMap();
/*     */     try {
/* 114 */       BaseStatementHandler delegate = (BaseStatementHandler)ReflectUtil.getValueByFieldName(statementHandler, "delegate");
/* 115 */       MappedStatement mappedStatement = (MappedStatement)ReflectUtil.getValueByFieldName(delegate, "mappedStatement");
/* 116 */       BoundSql boundSql = delegate.getBoundSql();
/* 117 */       Object parameterObject = boundSql.getParameterObject();
/* 118 */       String sql = boundSql.getSql();
/* 119 */       String sumSql = getSumSql(sql, page);
/* 120 */       PreparedStatement sumStatement = connection.prepareStatement(sumSql);
/* 121 */       BoundSql sumBoundSql = new BoundSql(mappedStatement.getConfiguration(), sumSql, boundSql.getParameterMappings(), parameterObject);
/* 122 */       setParameters(sumStatement, mappedStatement, sumBoundSql, parameterObject);
/* 123 */       ResultSet rs = sumStatement.executeQuery();
/* 124 */       if (rs.next()) {
/* 125 */         for (String sumColumn : page.getSumColumns()) {
/* 126 */           sumResultMap.put(sumColumn, rs.getString(sumColumn));
/*     */         }
/*     */       }
/* 129 */       rs.close();
/* 130 */       sumStatement.close();
/* 131 */       page.setSumResult(sumResultMap);
/*     */     } catch (SQLException e) {
/* 133 */       this.logger.error("error", e);
/*     */     }
/* 135 */     return sumResultMap;
/*     */   }
/*     */ 
/*     */   private String getSumSql(String sql, Page page) {
/* 139 */     String sumSql = "SELECT ";
/* 140 */     for (String column : page.getSumColumns()) {
/* 141 */       sumSql = new StringBuilder().append(sumSql).append(" IFNULL(SUM(").append(column).append("),0) AS ").append(column).append(",").toString();
/*     */     }
/* 143 */     sql = new StringBuilder().append(sumSql.substring(0, sumSql.length() - 1)).append(" FROM (").append(sql).append(") a").toString();
/* 144 */     return sql;
/*     */   }
/*     */ 
/*     */   private void setParameters(PreparedStatement ps, MappedStatement mappedStatement, BoundSql boundSql, Object parameterObject)
/*     */     throws SQLException
/*     */   {
/* 158 */     ErrorContext.instance().activity("setting parameters").object(mappedStatement.getParameterMap().getId());
/* 159 */     List parameterMappings = boundSql.getParameterMappings();
/* 160 */     if (parameterMappings != null) {
/* 161 */       Configuration configuration = mappedStatement.getConfiguration();
/* 162 */       TypeHandlerRegistry typeHandlerRegistry = configuration.getTypeHandlerRegistry();
/* 163 */       MetaObject metaObject = parameterObject == null ? null : configuration.newMetaObject(parameterObject);
/* 164 */       for (int i = 0; i < parameterMappings.size(); i++) {
/* 165 */         ParameterMapping parameterMapping = (ParameterMapping)parameterMappings.get(i);
/* 166 */         if (parameterMapping.getMode() == ParameterMode.OUT)
/*     */           continue;
/* 168 */         String propertyName = parameterMapping.getProperty();
/* 169 */         PropertyTokenizer prop = new PropertyTokenizer(propertyName);
/*     */         Object value;
/*     */         Object value;
/* 170 */         if (parameterObject == null) {
/* 171 */           value = null;
/*     */         }
/*     */         else
/*     */         {
/*     */           Object value;
/* 172 */           if (typeHandlerRegistry.hasTypeHandler(parameterObject.getClass())) {
/* 173 */             value = parameterObject;
/*     */           }
/*     */           else
/*     */           {
/*     */             Object value;
/* 174 */             if (boundSql.hasAdditionalParameter(propertyName)) {
/* 175 */               value = boundSql.getAdditionalParameter(propertyName);
/* 176 */             } else if ((propertyName.startsWith("__frch_")) && (boundSql.hasAdditionalParameter(prop.getName()))) {
/* 177 */               Object value = boundSql.getAdditionalParameter(prop.getName());
/* 178 */               if (value != null)
/* 179 */                 value = configuration.newMetaObject(value).getValue(propertyName.substring(prop.getName().length()));
/*     */             }
/*     */             else {
/* 182 */               value = metaObject == null ? null : metaObject.getValue(propertyName);
/*     */             }
/*     */           }
/*     */         }
/* 184 */         TypeHandler typeHandler = parameterMapping.getTypeHandler();
/* 185 */         if (typeHandler == null) {
/* 186 */           throw new ExecutorException(new StringBuilder().append("There was no TypeHandler found for parameter ").append(propertyName).append(" of statement ").append(mappedStatement.getId()).toString());
/*     */         }
/* 188 */         typeHandler.setParameter(ps, i + 1, value, parameterMapping.getJdbcType());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private String generatePageSql(String sql, Page page)
/*     */   {
/* 202 */     if ((page != null) && (StringUtil.notEmpty(dialect))) {
/* 203 */       StringBuilder pageSql = new StringBuilder();
/* 204 */       if ("mysql".equals(dialect)) {
/* 205 */         pageSql.append(sql).append(page.getSortField()).append(page.getSortOrder()).append(" limit ").append(page.getCurrentResult()).append(",").append(page.getPageSize());
/*     */       }
/* 212 */       else if ("oracle".equals(dialect)) {
/* 213 */         pageSql.append("select * from (select tmp_tb.*,ROWNUM row_id from (").append(sql).append(page.getSortField()).append(page.getSortOrder()).append(") as tmp_tb where ROWNUM<=").append(page.getCurrentResult() + page.getPageSize()).append(") where row_id>").append(page.getCurrentResult());
/*     */       }
/*     */ 
/* 222 */       return pageSql.toString();
/*     */     }
/* 224 */     return sql;
/*     */   }
/*     */ 
/*     */   public Object plugin(Object arg0)
/*     */   {
/* 229 */     return Plugin.wrap(arg0, this);
/*     */   }
/*     */ 
/*     */   public void setProperties(Properties p) {
/* 233 */     dialect = p.getProperty("dialect");
/* 234 */     if (StringUtil.isEmpty(dialect)) {
/*     */       try {
/* 236 */         throw new PropertyException("dialect property is not found!");
/*     */       } catch (PropertyException e) {
/* 238 */         this.logger.error("error", e);
/*     */       }
/*     */     }
/* 241 */     pageSqlId = p.getProperty("pageSqlId");
/* 242 */     if (StringUtil.isEmpty(pageSqlId))
/*     */       try {
/* 244 */         throw new PropertyException("pageSqlId property is not found!");
/*     */       } catch (PropertyException e) {
/* 246 */         this.logger.error("error", e);
/*     */       }
/*     */   }
/*     */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.mybatis.interceptor.PageInterceptor
 * JD-Core Version:    0.6.0
 */