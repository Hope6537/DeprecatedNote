/*     */ package com.gaoxinyu.sail.mybatis.interceptor;
/*     */ 
/*     */ import com.gaoxinyu.sail.mybatis.model.MapParam;
/*     */ import com.gaoxinyu.sail.util.ReflectUtil;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*     */ import org.apache.ibatis.executor.resultset.DefaultResultSetHandler;
/*     */ import org.apache.ibatis.plugin.Interceptor;
/*     */ import org.apache.ibatis.plugin.Intercepts;
/*     */ import org.apache.ibatis.plugin.Invocation;
/*     */ import org.apache.ibatis.plugin.Plugin;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ @Intercepts({@org.apache.ibatis.plugin.Signature(method="handleResultSets", type=org.apache.ibatis.executor.resultset.ResultSetHandler.class, args={Statement.class})})
/*     */ public class MapInterceptor
/*     */   implements Interceptor
/*     */ {
/*  24 */   Logger logger = LoggerFactory.getLogger(getClass());
/*     */ 
/*     */   public Object intercept(Invocation invocation)
/*     */     throws Throwable
/*     */   {
/*  31 */     Object target = invocation.getTarget();
/*     */ 
/*  33 */     if ((target instanceof DefaultResultSetHandler)) {
/*  34 */       DefaultResultSetHandler resultSetHandler = (DefaultResultSetHandler)target;
/*     */ 
/*  36 */       ParameterHandler parameterHandler = (ParameterHandler)ReflectUtil.getValueByFieldName(resultSetHandler, "parameterHandler");
/*  37 */       Object parameterObj = parameterHandler.getParameterObject();
/*     */ 
/*  39 */       if ((parameterObj instanceof MapParam)) {
/*  40 */         MapParam mapParam = (MapParam)parameterObj;
/*     */ 
/*  42 */         Statement stmt = (Statement)invocation.getArgs()[0];
/*     */ 
/*  44 */         return handleResultSet(stmt.getResultSet(), mapParam);
/*  45 */       }if (((parameterObj instanceof Map)) && (((Map)parameterObj).containsKey("mapParam")) && ((((Map)parameterObj).get("mapParam") instanceof MapParam)))
/*     */       {
/*  47 */         MapParam mapParam = (MapParam)(MapParam)((Map)parameterObj).get("mapParam");
/*     */ 
/*  49 */         Statement stmt = (Statement)invocation.getArgs()[0];
/*     */ 
/*  51 */         return handleResultSet(stmt.getResultSet(), mapParam);
/*     */       }
/*     */     }
/*     */ 
/*  55 */     return invocation.proceed();
/*     */   }
/*     */ 
/*     */   private Object handleResultSet(ResultSet resultSet, MapParam mapParam)
/*     */   {
/*  67 */     if (resultSet != null)
/*     */     {
/*  69 */       String keyField = (String)mapParam.get("keyField");
/*     */ 
/*  71 */       String valueField = (String)mapParam.get("valueField");
/*     */ 
/*  73 */       Map map = new HashMap();
/*     */ 
/*  76 */       List resultList = new ArrayList();
/*     */       try
/*     */       {
/*  79 */         while (resultSet.next()) {
/*  80 */           Object key = resultSet.getObject(keyField);
/*  81 */           Object value = resultSet.getObject(valueField);
/*  82 */           map.put(key, value);
/*     */         }
/*     */       } catch (SQLException e) {
/*  85 */         this.logger.error("error", e);
/*     */       } finally {
/*  87 */         closeResultSet(resultSet);
/*     */       }
/*     */ 
/*  90 */       resultList.add(map);
/*  91 */       return resultList;
/*     */     }
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   private void closeResultSet(ResultSet resultSet)
/*     */   {
/*     */     try
/*     */     {
/* 103 */       if (resultSet != null)
/* 104 */         resultSet.close();
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object plugin(Object obj)
/*     */   {
/* 115 */     return Plugin.wrap(obj, this);
/*     */   }
/*     */ 
/*     */   public void setProperties(Properties props)
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.mybatis.interceptor.MapInterceptor
 * JD-Core Version:    0.6.0
 */