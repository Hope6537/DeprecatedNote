/*     */ package com.gaoxinyu.sail.mybatis.model;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Page
/*     */ {
/*     */   private static final int PAGE_SIZE = 30;
/*     */   private static final int FIRST_PAGE = 1;
/*     */   private static final int MAX_SUM_LIMIT = 10000;
/*     */   private int pageSize;
/*     */   private int totalPage;
/*     */   private int totalResult;
/*     */   private int pageNo;
/*     */   private int currentResult;
/*     */   private String sortField;
/*     */   private String sortOrder;
/*     */   private String[] sumColumns;
/*     */   private Map<String, String> sumResult;
/*     */ 
/*     */   public Page()
/*     */   {
/*  20 */     this.pageSize = 30;
/*  21 */     this.pageNo = 1;
/*     */   }
/*     */ 
/*     */   public Page(String pageNo) {
/*  25 */     this(String.valueOf(30), pageNo);
/*     */   }
/*     */ 
/*     */   public Page(String pageSize, String pageNo) {
/*     */     try {
/*  30 */       this.pageNo = Integer.parseInt(pageNo);
/*     */     } catch (NumberFormatException e) {
/*  32 */       this.pageNo = 1;
/*     */     }
/*     */     try {
/*  35 */       this.pageSize = Integer.parseInt(pageSize);
/*     */     } catch (NumberFormatException e) {
/*  37 */       this.pageSize = 30;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getTotalPage() {
/*  42 */     if (this.totalResult % this.pageSize == 0)
/*  43 */       this.totalPage = (this.totalResult / this.pageSize);
/*     */     else {
/*  45 */       this.totalPage = (this.totalResult / this.pageSize + 1);
/*     */     }
/*  47 */     return this.totalPage;
/*     */   }
/*     */ 
/*     */   public void setTotalPage(int totalPage) {
/*  51 */     this.totalPage = totalPage;
/*     */   }
/*     */ 
/*     */   public int getTotalResult() {
/*  55 */     return this.totalResult;
/*     */   }
/*     */ 
/*     */   public void setTotalResult(int totalResult) {
/*  59 */     this.totalResult = totalResult;
/*     */   }
/*     */ 
/*     */   public int getPageNo() {
/*  63 */     if (this.pageNo <= 0) {
/*  64 */       this.pageNo = 1;
/*     */     }
/*  66 */     if (this.pageNo > getTotalPage()) {
/*  67 */       this.pageNo = getTotalPage();
/*     */     }
/*  69 */     return this.pageNo;
/*     */   }
/*     */ 
/*     */   public void setPageNo(int pageNo) {
/*  73 */     this.pageNo = pageNo;
/*     */   }
/*     */ 
/*     */   public int getPageSize() {
/*  77 */     return this.pageSize;
/*     */   }
/*     */ 
/*     */   public void setPageSize(int pageSize) {
/*  81 */     this.pageSize = pageSize;
/*     */   }
/*     */ 
/*     */   public int getCurrentResult() {
/*  85 */     this.currentResult = ((getPageNo() - 1) * getPageSize());
/*  86 */     if (this.currentResult < 0) {
/*  87 */       this.currentResult = 0;
/*     */     }
/*  89 */     return this.currentResult;
/*     */   }
/*     */ 
/*     */   public void setCurrentResult(int currentResult) {
/*  93 */     this.currentResult = currentResult;
/*     */   }
/*     */ 
/*     */   public String[] getSumColumns() {
/*  97 */     return this.sumColumns;
/*     */   }
/*     */ 
/*     */   public void setSumColumns(String[] sumColumns) {
/* 101 */     this.sumColumns = sumColumns;
/*     */   }
/*     */ 
/*     */   public boolean hasSumColumns() {
/* 105 */     return (this.sumColumns != null) && (this.sumColumns.length > 0);
/*     */   }
/*     */ 
/*     */   public boolean lessThanMaxSumLimit() {
/* 109 */     return this.totalResult < 10000;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getSumResult() {
/* 113 */     return this.sumResult;
/*     */   }
/*     */ 
/*     */   public void setSumResult(Map<String, String> sumResult) {
/* 117 */     this.sumResult = sumResult;
/*     */   }
/*     */ 
/*     */   public String getSortField() {
/* 121 */     return this.sortField == null ? "" : this.sortField;
/*     */   }
/*     */ 
/*     */   public void setSortField(String sortField) {
/* 125 */     setSortField(sortField, "");
/*     */   }
/*     */ 
/*     */   public void setSortField(String sortField, String defaultStr) {
/* 129 */     if ((sortField == null) || (sortField.equals("")) || (sortField.equals("null")))
/* 130 */       this.sortField = defaultStr;
/*     */     else
/* 132 */       this.sortField = new StringBuilder().append(" ORDER BY ").append(sortField.endsWith("IsNum") ? sortField.substring(0, sortField.lastIndexOf("IsNum")) : new StringBuilder().append(" CONVERT(").append(sortField).append(" USING gbk)").toString()).toString();
/*     */   }
/*     */ 
/*     */   public void setDefaultSortSql(String sortSql)
/*     */   {
/* 137 */     if ((this.sortField == null) || (this.sortField.equals(""))) {
/* 138 */       this.sortField = sortSql;
/* 139 */       this.sortOrder = "";
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getSortOrder() {
/* 144 */     return this.sortOrder == null ? "" : this.sortOrder;
/*     */   }
/*     */ 
/*     */   public void setSortOrder(String sortOrder) {
/* 148 */     this.sortOrder = ((sortOrder == null) || (sortOrder.equals("null")) ? "" : sortOrder);
/*     */   }
/*     */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.mybatis.model.Page
 * JD-Core Version:    0.6.0
 */