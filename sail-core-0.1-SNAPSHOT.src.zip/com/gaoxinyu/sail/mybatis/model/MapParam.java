/*    */ package com.gaoxinyu.sail.mybatis.model;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class MapParam extends HashMap<String, Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   public static final String KEY_FIELD = "keyField";
/*    */   public static final String VALUE_FIELD = "valueField";
/*    */ 
/*    */   public MapParam()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MapParam(String keyField, String valueField)
/*    */   {
/* 32 */     put("keyField", keyField);
/* 33 */     put("valueField", valueField);
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.mybatis.model.MapParam
 * JD-Core Version:    0.6.0
 */