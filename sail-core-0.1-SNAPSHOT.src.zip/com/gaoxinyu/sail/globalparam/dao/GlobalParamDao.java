package com.gaoxinyu.sail.globalparam.dao;

import com.gaoxinyu.sail.annotation.mybatisRepository;
import com.gaoxinyu.sail.globalparam.model.GlobalParam;
import java.util.List;

@mybatisRepository
public abstract interface GlobalParamDao
{
  public abstract int addGlobalParam(GlobalParam paramGlobalParam);

  public abstract List<GlobalParam> getGlobalParamList(GlobalParam paramGlobalParam);

  public abstract int updateGlobalParam(GlobalParam paramGlobalParam);

  public abstract GlobalParam getGlobalParamListByParamName(String paramString);
}

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.globalparam.dao.GlobalParamDao
 * JD-Core Version:    0.6.0
 */