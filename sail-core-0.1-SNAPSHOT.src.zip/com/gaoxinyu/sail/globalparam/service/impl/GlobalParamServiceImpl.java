/*    */ package com.gaoxinyu.sail.globalparam.service.impl;
/*    */ 
/*    */ import com.gaoxinyu.sail.globalparam.dao.GlobalParamDao;
/*    */ import com.gaoxinyu.sail.globalparam.model.GlobalParam;
/*    */ import com.gaoxinyu.sail.globalparam.service.GlobalParamService;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;
/*    */ import org.springframework.transaction.annotation.Transactional;
/*    */ 
/*    */ @Service("globalParamService")
/*    */ @Transactional
/*    */ public class GlobalParamServiceImpl
/*    */   implements GlobalParamService
/*    */ {
/*    */ 
/*    */   @Autowired
/*    */   private GlobalParamDao globalParamDao;
/*    */   private Map<String, String> dictGlobalParamMap;
/*    */ 
/*    */   public Map<String, String> getDictGlobalParamMap()
/*    */   {
/* 25 */     return this.dictGlobalParamMap;
/*    */   }
/*    */ 
/*    */   @PostConstruct
/*    */   public void initDictGlobalParam() {
/* 31 */     Map map = new HashMap();
/* 32 */     for (GlobalParam globalParam : getGlobalParamList(new GlobalParam())) {
/* 33 */       map.put(globalParam.getParamName(), globalParam.getParamValue());
/*    */     }
/* 35 */     this.dictGlobalParamMap = map;
/*    */   }
/*    */ 
/*    */   public int addGlobalParam(GlobalParam globalParam)
/*    */   {
/* 40 */     return this.globalParamDao.addGlobalParam(globalParam);
/*    */   }
/*    */ 
/*    */   public String getGlobalParamFromCache(String paramName)
/*    */   {
/* 45 */     return (String)getDictGlobalParamMap().get(paramName);
/*    */   }
/*    */ 
/*    */   public List<GlobalParam> getGlobalParamList(GlobalParam globalParam)
/*    */   {
/* 50 */     return this.globalParamDao.getGlobalParamList(globalParam);
/*    */   }
/*    */ 
/*    */   public void globalParamInitSetting(List<GlobalParam> paramList)
/*    */   {
/* 55 */     for (GlobalParam globalParam : paramList) {
/* 56 */       updateGlobalParam(globalParam);
/*    */     }
/* 58 */     initDictGlobalParam();
/*    */   }
/*    */ 
/*    */   public int updateGlobalParam(GlobalParam globalParam)
/*    */   {
/* 63 */     return this.globalParamDao.updateGlobalParam(globalParam);
/*    */   }
/*    */ 
/*    */   public int updateGlobalParamAndRefresh(GlobalParam globalParam)
/*    */   {
/* 68 */     int returnValue = updateGlobalParam(globalParam);
/* 69 */     initDictGlobalParam();
/* 70 */     return returnValue;
/*    */   }
/*    */ 
/*    */   public GlobalParam getGlobalParamFromDatabase(String paramName)
/*    */   {
/* 75 */     return this.globalParamDao.getGlobalParamListByParamName(paramName);
/*    */   }
/*    */ 
/*    */   public boolean checkGlobalParamOpen(String paramName)
/*    */   {
/* 80 */     return getGlobalParamFromCache(paramName).equals("1");
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.globalparam.service.impl.GlobalParamServiceImpl
 * JD-Core Version:    0.6.0
 */