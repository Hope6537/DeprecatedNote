package com.gaoxinyu.sail.globalparam.service;

import com.gaoxinyu.sail.globalparam.model.GlobalParam;
import java.util.List;

public abstract interface GlobalParamService
{
  public abstract void initDictGlobalParam();

  public abstract int addGlobalParam(GlobalParam paramGlobalParam);

  public abstract String getGlobalParamFromCache(String paramString);

  public abstract List<GlobalParam> getGlobalParamList(GlobalParam paramGlobalParam);

  public abstract void globalParamInitSetting(List<GlobalParam> paramList);

  public abstract int updateGlobalParam(GlobalParam paramGlobalParam);

  public abstract int updateGlobalParamAndRefresh(GlobalParam paramGlobalParam);

  public abstract GlobalParam getGlobalParamFromDatabase(String paramString);

  public abstract boolean checkGlobalParamOpen(String paramString);
}

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.globalparam.service.GlobalParamService
 * JD-Core Version:    0.6.0
 */