/*    */ package com.gaoxinyu.sail.globalparam.tag;
/*    */ 
/*    */ import com.gaoxinyu.sail.globalparam.service.GlobalParamService;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.tagext.TagSupport;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*    */ 
/*    */ public class GlobalParamTag extends TagSupport
/*    */ {
/*    */   private String name;
/*    */ 
/*    */   public int doStartTag()
/*    */     throws JspException
/*    */   {
/*    */     try
/*    */     {
/* 23 */       ApplicationContext applicationContext = WebApplicationContextUtils.getWebApplicationContext(this.pageContext.getServletContext());
/* 24 */       GlobalParamService globalParamService = (GlobalParamService)applicationContext.getBean("globalParamService");
/*    */ 
/* 26 */       JspWriter out = this.pageContext.getOut();
/* 27 */       out.print(globalParamService.getGlobalParamFromCache(this.name));
/*    */     } catch (Exception e) {
/* 29 */       throw new JspException(e.getMessage());
/*    */     }
/*    */ 
/* 32 */     return 0;
/*    */   }
/*    */ 
/*    */   public int doEndTag()
/*    */     throws JspException
/*    */   {
/* 38 */     return 6;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 42 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 46 */     this.name = name;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.globalparam.tag.GlobalParamTag
 * JD-Core Version:    0.6.0
 */