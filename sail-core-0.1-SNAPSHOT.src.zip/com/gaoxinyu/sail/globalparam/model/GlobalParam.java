/*    */ package com.gaoxinyu.sail.globalparam.model;
/*    */ 
/*    */ import com.gaoxinyu.sail.mybatis.model.Page;
/*    */ 
/*    */ public class GlobalParam extends Page
/*    */ {
/*    */   private String paramName;
/*    */   private String paramValue;
/*    */   private String paramDescription;
/*    */ 
/*    */   public GlobalParam()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GlobalParam(String paramName, String paramValue)
/*    */   {
/* 16 */     this.paramName = paramName;
/* 17 */     this.paramValue = paramValue;
/*    */   }
/*    */ 
/*    */   public String getParamName() {
/* 21 */     return this.paramName;
/*    */   }
/*    */ 
/*    */   public void setParamName(String paramName) {
/* 25 */     this.paramName = paramName;
/*    */   }
/*    */ 
/*    */   public String getParamValue() {
/* 29 */     return this.paramValue;
/*    */   }
/*    */ 
/*    */   public void setParamValue(String paramValue) {
/* 33 */     this.paramValue = paramValue;
/*    */   }
/*    */ 
/*    */   public String getParamDescription() {
/* 37 */     return this.paramDescription;
/*    */   }
/*    */ 
/*    */   public void setParamDescription(String paramDescription) {
/* 41 */     this.paramDescription = paramDescription;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.globalparam.model.GlobalParam
 * JD-Core Version:    0.6.0
 */