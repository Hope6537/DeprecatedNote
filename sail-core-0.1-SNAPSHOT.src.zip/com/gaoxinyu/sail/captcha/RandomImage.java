package com.gaoxinyu.sail.captcha;

import java.awt.image.BufferedImage;

public abstract interface RandomImage
{
  public abstract BufferedImage getValidateImage();

  public abstract String getValidateString();
}

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.captcha.RandomImage
 * JD-Core Version:    0.6.0
 */