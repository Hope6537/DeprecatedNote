/*    */ package com.gaoxinyu.sail.captcha.impl;
/*    */ 
/*    */ import com.gaoxinyu.sail.captcha.AbstractRandomImage;
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class RandomImageImpl extends AbstractRandomImage
/*    */ {
/*    */   public RandomImageImpl(int length, int width, int height)
/*    */   {
/* 13 */     super(length, width, height);
/*    */   }
/*    */ 
/*    */   protected void createVerificationCodeImage()
/*    */   {
/* 19 */     BufferedImage image = new BufferedImage(this.width, this.height, 1);
/* 20 */     Graphics g = image.getGraphics();
/* 21 */     g.setColor(getRandomColor(180, 250));
/* 22 */     g.fillRect(0, 0, this.width, this.height);
/* 23 */     StringBuilder validationCode = new StringBuilder();
/* 24 */     String[] fontNames = { "Times New Roman", "Arial" };
/* 25 */     Random r = new Random();
/*    */ 
/* 27 */     for (int i = 0; i < this.length; i++) {
/* 28 */       g.setFont(new Font(fontNames[r.nextInt(2)], 1, this.height));
/* 29 */       char codeChar = "0123456789".charAt(r.nextInt("0123456789".length()));
/* 30 */       validationCode.append(codeChar);
/* 31 */       g.setColor(getRandomColor(10, 100));
/* 32 */       g.drawString(String.valueOf(codeChar), 16 * i + r.nextInt(7), this.height - r.nextInt(6));
/*    */     }
/* 34 */     this.validateString = validationCode.toString();
/*    */ 
/* 36 */     for (int i = 0; i < 30; i++) {
/* 37 */       g.setColor(getRandomColor(90, 200));
/* 38 */       int x = r.nextInt(this.width);
/* 39 */       int y = r.nextInt(this.height);
/* 40 */       g.drawLine(x, y, x + r.nextInt(10), y + r.nextInt(5));
/*    */     }
/* 42 */     g.dispose();
/* 43 */     this.validateImage = image;
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.captcha.impl.RandomImageImpl
 * JD-Core Version:    0.6.0
 */