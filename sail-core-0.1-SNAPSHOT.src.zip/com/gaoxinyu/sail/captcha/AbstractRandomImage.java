/*    */ package com.gaoxinyu.sail.captcha;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.Random;
/*    */ 
/*    */ public abstract class AbstractRandomImage
/*    */   implements RandomImage
/*    */ {
/*    */   protected static final String randomString = "0123456789";
/*    */   protected String validateString;
/*    */   protected BufferedImage validateImage;
/*    */   protected int length;
/*    */   protected int width;
/*    */   protected int height;
/*    */ 
/*    */   protected AbstractRandomImage()
/*    */   {
/* 18 */     this.width = 100;
/* 19 */     this.height = 22;
/* 20 */     this.length = 6;
/*    */   }
/*    */ 
/*    */   public AbstractRandomImage(int length, int width, int height)
/*    */   {
/* 31 */     this.length = length;
/* 32 */     this.width = width;
/* 33 */     this.height = height;
/*    */   }
/*    */ 
/*    */   public String getValidateString()
/*    */   {
/* 39 */     if (this.validateString == null) {
/* 40 */       createVerificationCodeImage();
/*    */     }
/* 42 */     return this.validateString;
/*    */   }
/*    */ 
/*    */   public BufferedImage getValidateImage()
/*    */   {
/* 47 */     if (this.validateImage == null) {
/* 48 */       createVerificationCodeImage();
/*    */     }
/* 50 */     return this.validateImage;
/*    */   }
/*    */   protected abstract void createVerificationCodeImage();
/*    */ 
/*    */   protected Color getRandomColor(int frontColor, int backColor) {
/* 56 */     Random random = new Random();
/* 57 */     if (frontColor > 255) {
/* 58 */       frontColor = 255;
/*    */     }
/* 60 */     if (backColor > 255) {
/* 61 */       backColor = 255;
/*    */     }
/* 63 */     int red = frontColor + random.nextInt(backColor - frontColor);
/* 64 */     int green = frontColor + random.nextInt(backColor - frontColor);
/* 65 */     int blue = frontColor + random.nextInt(backColor - frontColor);
/* 66 */     return new Color(red, green, blue);
/*    */   }
/*    */ }

/* Location:           E:\Program Files\maven-3.2.3\repo\hope6537\com\gaoxinyu\sail\sail-core\0.1-SNAPSHOT\sail-core-0.1-SNAPSHOT.jar
 * Qualified Name:     com.gaoxinyu.sail.captcha.AbstractRandomImage
 * JD-Core Version:    0.6.0
 */