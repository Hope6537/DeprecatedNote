/** 
 *<pre>
 *Lucene查询
 *1、关键词查询
 *2、查询所有文档
 *3、范围查询
 *4、通配符查询 重要
 *5、短语查询
 *6、布尔查询
 *</pre>
 */
package org.hope6537.lucene.query;