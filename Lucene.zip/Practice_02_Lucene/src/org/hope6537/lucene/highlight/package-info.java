/** 
 *<pre>
 *高亮器
 *</pre>
 */
package org.hope6537.lucene.highlight;